<?php
return [
    'loading' => 'Loading...',
];
