<?php

return [
    'name' => 'Customer',
    'title' => 'Customer Management',
    'customer_report' => 'Customer Report',

    'button' => [
        'create' => 'Create Customer',
        'import' => 'Import Customers',
    ],

    'table' => [
        'code' => 'Customer Code',
    ],

    'empty' => [
        'title' => 'Customer is empty',
        'description' => 'You can create a new Customer by clicking the button below.',
    ],

    'form' => [
        'title' => [
            'create' => 'Create Customer',
            'update' => 'Update Customer',
            'change_password' => 'Change Password',
        ],
        'code' => [
            'label' => 'Customer Code',
            'placeholder' => 'Enter customer code ...',
        ],
        'name' => [
            'label' => 'Name',
            'placeholder' => 'Enter name ...',
        ],
        'phone' => [
            'label' => 'Phone',
            'placeholder' => 'Enter phone ...',
        ],
        'email' => [
            'label' => 'Email',
            'placeholder' => 'Enter email ...',
        ],
        'address' => [
            'label' => 'Address',
            'placeholder' => 'Enter address ...',
        ],
        'password' => [
            'label' => 'Password',
            'placeholder' => 'Enter password',
        ],
        'new_password' => [
            'label' => 'New Password',
            'placeholder' => 'Enter new password',
        ],
        'password_confirmation' => [
            'label' => 'Confirm Password',
            'placeholder' => 'Confirm password',
        ],
        'profile' => [
            'label' => 'Profile',
            'placeholder' => 'Enter profile',
        ],
        'id_card' => [
            'label' => 'ID Card',
            'placeholder' => 'Enter id card',
        ],
        'payment_restriction' => [
            'label' => 'Payment Restriction',
            'yes'   => 'Yes',
            'no'    => 'No',
        ],
    ],

    'validation' => [
        'code_max' => 'The customer code may not be greater than 50 characters.',
        'code_unique' => 'The customer code has already been taken.',
        'name_required' => 'Please enter the customer name.',
        'name_max' => 'The name may not be greater than 255 characters.',
        'phone_required' => 'Please enter the phone number.',
        'phone_max' => 'The phone may not be greater than 50 characters.',
        'password_required' => 'Password is required.',
        'password_min' => 'Password must be at least 6 characters.',
        'password_confirmed' => 'Password confirmation does not match.',
        'status_required' => 'Status is required.',
        'status_boolean' => 'Status must be true or false.',
        'status_invalid' => 'The selected status is invalid.',
        'payment_restriction_required' => 'Payment restriction selection is required.',
        'payment_restriction_invalid' => 'The selected payment restriction is invalid.',
    ],
];
