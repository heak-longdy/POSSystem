var menuShowHide = localStorage.getItem("menu");
const { updateSidebarActive } = require("../workspace/sidebar-active");

// SIDEBAR DROPDOWN
const allDropdown = document.querySelectorAll("#sidebar .side-dropdown");
const sidebar = document.getElementById("sidebar");
updateSidebarActive(window.location.href);

allDropdown.forEach((item) => {
    const a = item.parentElement.querySelector("a:first-child");
    a.addEventListener("click", function (e) {
        e.preventDefault();

        if (!item.classList.contains("show")) {
            allDropdown.forEach((i) => {
                const aLink = i.parentElement.querySelector("a:first-child");

                aLink.classList.toggle("active", aLink.dataset.routeActive === "true");
                i.classList.remove("show");
            });
        }

        item.classList.toggle("show");
        this.classList.toggle("active", item.classList.contains("show") || this.dataset.routeActive === "true");
    });
});

// SIDEBAR LINK NAVIGATION (Suppresses browser bottom-left URL preview)
const sidebarLinks = document.querySelectorAll("#sidebar .side-menu a[data-url]");
sidebarLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
        if (!this.parentElement.querySelector(".side-dropdown")) {
            const url = this.getAttribute("data-url");
            if (url && url !== "#") {
                if (e.ctrlKey || e.metaKey) {
                    window.open(url, "_blank");
                } else if (window.MDI && typeof window.MDI.openUrlInTab === "function") {
                    e.preventDefault();
                    const title = this.textContent.trim();
                    const iconEl = this.querySelector("i.icon");
                    let icon = "bx bx-file";
                    if (iconEl) {
                        const iconClasses = Array.from(iconEl.classList).filter(c => c !== "icon");
                        if (iconClasses.length > 0) icon = iconClasses.join(" ");
                    }
                    window.MDI.openUrlInTab(url, title, icon);
                } else {
                    window.location.href = url;
                }
            }
        }
    });

    link.addEventListener("auxclick", function (e) {
        if (e.button === 1) {
            const url = this.getAttribute("data-url");
            if (url && url !== "#") {
                window.open(url, "_blank");
            }
        }
    });
});

const allSidebarInteractive = document.querySelectorAll("#sidebar .side-menu a, #sidebar .brand");
allSidebarInteractive.forEach((el) => {
    el.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
            this.click();
        }
    });
});

// var switchDark = localStorage.getItem("switchDarkMode");

// var switchMode = document.getElementById("switch-mode");
// if (switchDark == 1) {
//     document.body.classList.add("dark");
//     switchMode.checked = true;
// }
// switchMode.addEventListener("change", function () {
//     if (this.checked) {
//         document.body.classList.add("dark");
//         localStorage.setItem("switchDarkMode", 1);
//     } else {
//         document.body.classList.remove("dark");
//         localStorage.setItem("switchDarkMode", 0);
//     }
// });

// SIDEBAR COLLAPSE
// const toggleSidebar = document.querySelector("nav .toggle-sidebar");
const toggleSidebar = document.querySelector("button.toggle-sidebar");
const allSideDivider = document.querySelectorAll("#sidebar .divider");

if (menuShowHide === "0") {
    sidebar.classList.add("hide");
} else if (menuShowHide === "1") {
    sidebar.classList.remove("hide");
}

if (sidebar.classList.contains("hide")) {
    allSideDivider.forEach((item) => {
        item.textContent = "-";
    });
    allDropdown.forEach((item) => {
        const a = item.parentElement.querySelector("a:first-child");
        a.classList.toggle("active", a.dataset.routeActive === "true");
        item.classList.remove("show");
    });
} else {
    allSideDivider.forEach((item) => {
        item.textContent = item.dataset.text;
    });
}

toggleSidebar.addEventListener("click", function () {
    sidebar.classList.toggle("hide");
    if (sidebar.classList.contains("hide")) {
        localStorage.setItem("menu", "0");
        allSideDivider.forEach((item) => {
            item.textContent = "-";
        });

        allDropdown.forEach((item) => {
            const a = item.parentElement.querySelector("a:first-child");
            a.classList.toggle("active", a.dataset.routeActive === "true");
            item.classList.remove("show");
        });
    } else {
        localStorage.setItem("menu", "1");
        allSideDivider.forEach((item) => {
            item.textContent = item.dataset.text;
        });
        updateSidebarActive(window.location.href);
    }
});

sidebar.addEventListener("mouseleave", function () {
    if (this.classList.contains("hide")) {
        allDropdown.forEach((item) => {
            const a = item.parentElement.querySelector("a:first-child");
            a.classList.toggle("active", a.dataset.routeActive === "true");
            item.classList.remove("show");
        });
        allSideDivider.forEach((item) => {
            item.textContent = "-";
        });
    }
});

sidebar.addEventListener("mouseenter", function () {
    if (this.classList.contains("hide")) {
        allDropdown.forEach((item) => {
            const a = item.parentElement.querySelector("a:first-child");
            a.classList.toggle("active", a.dataset.routeActive === "true");
            item.classList.remove("show");
        });
        allSideDivider.forEach((item) => {
            item.textContent = item.dataset.text;
        });
    }
});

// PROFILE DROPDOWN
const profile = document.querySelector("nav .profile");
if (profile && !profile.hasAttribute("x-data") && !profile.closest("[x-data]")) {
    const imgProfile = profile.querySelector("img");
    const dropdownProfile = profile.querySelector(".profile-link");

    if (imgProfile && dropdownProfile) {
        imgProfile.addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            dropdownProfile.classList.toggle("show");
        });
        window.addEventListener("click", function (e) {
            if (!e.target.closest(".profile")) {
                if (dropdownProfile.classList.contains("show")) {
                    dropdownProfile.classList.remove("show");
                }
            }
        });
    }
}
    // allMenu.forEach((item) => {
    //     const icon = item.querySelector(".icon");
    //     const menuLink = item.querySelector(".menu-link");

    //     if (e.target !== icon) {
    //         if (e.target !== menuLink) {
    //             if (menuLink.classList.contains("show")) {
    //                 menuLink.classList.remove("show");
    //             }
    //         }
    //     }
    // });

// Notification DROPDOWN
const notification = document.querySelector(".header.main-header-navbar .notificationGp");
if (notification) {
    const eventNotification = notification.querySelector(".notification");
    const dropdownNotification = notification.querySelector(".notification-body");

    if (eventNotification && dropdownNotification) {
        eventNotification.addEventListener("click", function (e) {
            e.preventDefault();
            dropdownNotification.classList.toggle("show");
        });
        window.addEventListener("click", function (e) {
            if (!e.target.closest(".notificationGp")) {
                if (dropdownNotification.classList.contains("show")) {
                    dropdownNotification.classList.remove("show");
                }
            }
        });
    }
}

// MENU
const allMenu = document.querySelectorAll("main .content-data .head .menu");

allMenu.forEach((item) => {
    const icon = item.querySelector(".icon");
    const menuLink = item.querySelector(".menu-link");

    icon.addEventListener("click", function () {
        menuLink.classList.toggle("show");
    });
});

// MENU
var MenuDropDown = document.querySelectorAll(".menu");
MenuDropDown.forEach(function (item) {
    var icon = item.querySelector(".icon");
    var menuLink = item.querySelector(".menu-link");
    icon.addEventListener("click", function () {
        menuLink.classList.toggle("show");
    });
});

//slidBarScrollActive
const menu_activeDom = document.querySelector("#sidebar .side-menu .li .active");
// const menu_activeDom = document.querySelector("#sidebar .side-menu .navItemSiderbarGroup .navSidber li.active")
const menu_listDom = document.getElementsByClassName("side-menu")[0];
menu_listDom?.scrollTo({
    top: menu_activeDom?.offsetTop - menu_listDom?.clientHeight / 2,
    left: 0,
    behavior: "smooth",
});

// content
// const contentMain = document.querySelector("#content main");
// var el = document.getElementById("jsScroll");
// var lastScrollTop = 0;
// contentMain.addEventListener("scroll", (e) => {
//     var st = window.pageYOffset || contentMain.scrollTop;
//    if (st > lastScrollTop) {
//     el.classList.add("visible");
//    } else if (st < lastScrollTop) {
//     el.classList.remove("visible");
//    }
//    lastScrollTop = st <= 0 ? 0 : st;

// },false);
// el.addEventListener("click", function () {
//     lastScrollTop = 0;
//     contentMain.scrollTo({
//         top: 0,
//         behavior: "smooth",
//     });
// });
