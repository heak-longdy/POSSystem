<div class="file-manager-wrapper" x-data="fileManager" :class="{'full-page':fileManagerState.full_page}">
    <div class="file-manager-header" x-show="!fileManagerState.full_page">
        <div class="label">
            <span>@lang('file-manager.title')</span>
        </div>
        <div class="gap"></div>
        <button @click="onClose()">
            <i data-feather="x"></i>
            <span>@lang('file-manager.button.close')</span>
        </button>
    </div>
    <div class="file-manager-body">
        <div class="breadcrumb">
            <span @click="firstPage()">
                @lang('file-manager.breadcrumb.all_files')
            </span>
            <template x-for="(folder,index) in dataFolders">
                <span @click="onBreadcrumbClick(folder,index)">
                    <i data-feather="chevron-right"></i>
                    <i data-feather="folder" class="folder-icon"></i>
                    <span x-text="folder?.name"></span>
                </span>
            </template>
        </div>
        <div class="file-side">
            @include('admin::file-manager.menu')
            <div class="file-list" *ngIf="!store?.fileLoading && store?.dataFile?.length > 0">
                <div class="action">
                    <div class="form-row">
                        <input type="text" placeholder="@lang('file-manager.input.search')"
                            x-on:input="onSearch($event)">
                        <i data-feather="search"></i>
                    </div>
                    <button @click="reloadPage()" class="reload">
                        {{-- <i data-feather="refresh-cw"></i> --}}
                        <i class='bx bx-revision'></i>
                        {{-- <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.89 10.105a8.696 8.696 0 0 0-.789-1.456l-1.658 1.119a6.606 6.606 0 0 1 .987 2.345 6.659 6.659 0 0 1 0 2.648 6.495 6.495 0 0 1-.384 1.231 6.404 6.404 0 0 1-.603 1.112 6.654 6.654 0 0 1-1.776 1.775 6.606 6.606 0 0 1-2.343.987 6.734 6.734 0 0 1-2.646 0 6.55 6.55 0 0 1-3.317-1.788 6.605 6.605 0 0 1-1.408-2.088 6.613 6.613 0 0 1-.382-1.23 6.627 6.627 0 0 1 .382-3.877A6.551 6.551 0 0 1 7.36 8.797 6.628 6.628 0 0 1 9.446 7.39c.395-.167.81-.296 1.23-.382.107-.022.216-.032.324-.049V10l5-4-5-4v2.938a8.805 8.805 0 0 0-.725.111 8.512 8.512 0 0 0-3.063 1.29A8.566 8.566 0 0 0 4.11 16.77a8.535 8.535 0 0 0 1.835 2.724 8.614 8.614 0 0 0 2.721 1.833 8.55 8.55 0 0 0 5.061.499 8.576 8.576 0 0 0 6.162-5.056c.22-.52.389-1.061.5-1.608a8.643 8.643 0 0 0 0-3.45 8.684 8.684 0 0 0-.499-1.607z"></path></svg> --}}
                        <span>@lang('file-manager.button.reload')</span>
                    </button>
                    <div class="gap"></div>
                    <button @click="dialog.open('uploadFileDialog')" class="full-fill">
                        <i data-feather="upload-cloud"></i>
                        <span>@lang('file-manager.button.upload_file')</span>
                    </button>
                    <button @click="dialog.open('createFolderDialog')">
                        <i data-feather="folder-plus"></i>
                        <span>@lang('file-manager.button.create_folder')</span>
                    </button>
                </div>
                <div class="file-list-wrapper" x-on:scroll="onScroll($event)">
                    <template x-if="!loading && folders.length > 0">
                        <div class="folder-row">
                            <template x-for="folder in folders">
                                <div class="folder-item" x-bind:class="isSelected(folder,'selected')"
                                    @click="onOpenFolder(folder);closeContextMenu();hideTooltip()"
                                    x-on:contextmenu="onRightClick($event,folder,'folder')"
                                    x-on:mousemove="showTooltip($event,folder)" x-on:mouseleave="hideTooltip()">
                                    <div class="img">
                                        <img x-bind:src="`{{ asset('images/logo/folder-empty.png') }}`" alt="">
                                    </div>
                                    <div class="name">
                                        <span x-text="folder.name"></span>
                                    </div>
                                    {{-- <template x-if="!isSelected(folder)">
                                            <div class="select-folder-icon" @click="onFolderSelected(folder)">
                                                <i data-feather="circle"></i>
                                            </div>
                                        </template>
                                        <template x-if="isSelected(folder)" @click="onFolderSelected(folder)">
                                            <div class="selected-folder-icon">
                                                <i data-feather="check-circle"></i>
                                            </div>
                                        </template> --}}
                                </div>
                            </template>
                        </div>
                    </template>
                    <template x-if="!loading && files.length > 0">
                        <div class="file-row">
                            <template x-for="(file,index) in files">
                                <div class="file-item" x-bind:class="isSelected(file,'selected')"
                                    x-on:contextmenu="onRightClick($event,file,'file')"
                                    x-on:mousemove="showTooltip($event,file)" x-on:mouseleave="hideTooltip()"
                                    @click="onSelectFiles(file)" x-on:dblclick="viewImage(file)">
                                    <div class="img">
                                        <img x-bind:src="base_path+file?.path" loading="lazy" decoding="async"
                                            onerror="(this).src='{{ asset('images/logo/default.png') }}'" alt="">
                                    </div>
                                    <div class="name">
                                        <span x-text="file?.name"></span>
                                    </div>
                                    <template x-if="!isSelected(file)">
                                        <div class="select-file-icon">
                                            {{-- <i data-feather="circle"></i> --}}
                                            <div></div>
                                        </div>
                                    </template>
                                    <template x-if="isSelected(file)">
                                        <div class="selected-file-icon">
                                            {{-- <i data-feather="check-circle"></i> --}}
                                            <div x-text="selectedIndex(file)"></div>
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </template>
                    <template x-if="!loading && files.length == 0 && folders.length == 0">
                        @component('admin::components.empty', ['name' => 'File not found', 'image' =>
                            asset('images/logo/em.svg'), 'style' => 'padding: 50px 0;'])
                        @endcomponent
                    </template>
                    <template x-if="loading || fileLoading">
                        <div class="skeleton-row">
                            <template x-for="skeleton in skeletons">
                                <div class="skeleton-item">
                                    <div class="img skeleton"></div>
                                    <div class="name skeleton"></div>
                                    <div class="name skeleton"></div>
                                </div>
                            </template>
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>
    <div class="file-manager-footer">
        <template x-if="selected_file.length > 0">
            <div class="file-manager-button">
                <button @click="onUnselectFiles">
                    <i data-feather="x"></i>
                    <span>@lang('file-manager.button.unselect_files')</span>
                </button>
                <button class="save" x-show="!fileManagerState.full_page" @click="onChooseFiles">
                    <i data-feather="check"></i>
                    <span>
                        @lang('file-manager.button.choose_files')
                        <span x-text="`(${selected_file.length})`"></span>
                    </span>
                </button>
            </div>
        </template>
    </div>
    <template x-if="dialog.component.createFolderDialog">
        @include('admin::file-manager.create-folder')
    </template>
    <template x-if="dialog.component.renameFolderDialog">
        @include('admin::file-manager.rename-folder')
    </template>
    <template x-if="dialog.component.uploadFileDialog">
        @include('admin::file-manager.upload-file')
    </template>
    <template x-if="dialog.component.trashConfirmDialog">
        @include('admin::file-manager.trash-dialog')
    </template>
    <template x-if="contentMenu.show">
        <div class="dialog">
            <div class="context-menu" :style="`top:${contentMenu.y}px;left:${contentMenu.x}px`">
                <div class="context-menu-item"
                    @click="contentMenu.type === 'file' ? viewImage(contentMenu?.data) : onOpenFolder(contentMenu?.data) "
                    @click.away="closeContextMenu">
                    <span>@lang('file-manager.button.open')</span>
                    <i data-feather="arrow-right"></i>
                </div>
                <template x-if="contentMenu.type === 'folder'">
                    <div class="context-menu-item" @click="dialog.open('renameFolderDialog')"
                        @click.away="closeContextMenu">
                        <span>@lang('file-manager.button.rename')</span>
                        <i data-feather="edit"></i>
                    </div>
                </template>
                <template x-if="contentMenu.type === 'file'">
                    <div class="context-menu-item" @click="copyLink(contentMenu?.data)" @click.away="closeContextMenu">
                        <span>@lang('file-manager.button.copy-link')</span>
                        <i data-feather="link"></i>
                    </div>
                </template>
                <div class="context-menu-item danger" @click="dialog.open('trashConfirmDialog')"
                    @click.away="closeContextMenu">
                    <span>@lang('file-manager.button.delete')</span>
                    <i data-feather="trash-2"></i>
                </div>
            </div>
        </div>
    </template>
    <template x-if="tooltip.show && !contentMenu.show">
        <div class="tooltipX" :style="`top:${tooltip.y}px;left:${tooltip.x}px`">
            <p>@lang('file-manager.tooltip.name') : <span x-text="tooltip.data?.name"></span></p>
            <p style="display: none" x-show="typeof tooltip.data?.folder_id != 'undefined'">
                @lang('file-manager.tooltip.size') : <span
                    x-text="new Intl.NumberFormat().format(tooltip.data?.size)+' bytes'"></span></p>
            <p style="display: none" x-show="tooltip.data?.is_image == 1">@lang('file-manager.tooltip.dimensions') :
                <span x-text="tooltip.data?.width+' x '+tooltip.data?.height"></span>
            </p>
            <p style="display: none" x-show="typeof tooltip.data?.folder_id != 'undefined'">
                @lang('file-manager.tooltip.type') : <span x-text="tooltip.data?.extension?.toUpperCase()"></span></p>
            <p style="display: none" x-show="typeof tooltip.data?.folder_id != 'undefined'">
                @lang('file-manager.tooltip.uploaded_at') : <span
                    x-text="moment(tooltip.data?.created_at).calendar()"></span></p>
            <template x-if="typeof tooltip.data?.folder_id == 'undefined'">
                <p>@lang('file-manager.tooltip.created_at') : <span
                        x-text="moment(tooltip.data?.created_at).calendar()"></span></p>
            </template>
        </div>
    </template>
</div>
