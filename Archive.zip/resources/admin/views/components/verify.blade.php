@if(!defined('ADMIN_VERIFY_POPUP_LOADED'))
@php define('ADMIN_VERIFY_POPUP_LOADED', true); @endphp
@component('admin::components.dialog', ['dialog' => 'confirmDialog'])
    <template x-if="$store?.confirmDialog?.data?.typeAction === 'order-products'">
        @include('admin::pages.order.product-picker')
    </template>
    <template x-if="$store?.confirmDialog?.data?.typeAction !== 'order-products'">
    <div x-data="verifyConfirmDialog" class="dialog-form" x-bind:style="{ width: data?.width }"
        style="text-align: center;align-items: center;">
        <div class="dialog-form-header" style="justify-content: center;">
            <template x-if="data?.icon">
                <i :class="data.icon"
                    :style="data?.iconStyle || 'font-size: 55px;margin-bottom: 15px; border: 1px solid rgba(16, 185, 129, 0.8); color: rgb(16 185 129); border-radius: 50%; padding: 4px;'"></i>
            </template>
            <template x-if="!data?.icon">
                <i class='bx bx-question-mark'
                    style="font-size: 55px;margin-bottom: 15px; border: 1px solid rgba(255, 0, 0, 0.8); color:rgb(255 0 0 / 61%); border-radius: 50%;"></i>
            </template>
        </div>
        <div class="dialog-form-body" style="padding: 15px 30px;">
            <div class="form-row" style="margin-bottom: 10px;">
                <p x-html="data?.message" style="text-align: left;font-weight: 600;"></p>
            </div>
            <template x-if="typeAction =='delete'">
                <div style="display: flex; align-items: center;grid-gap: 10px;margin: 0 5px; font-size: 14px;">
                    <label class="containerInputCheckBox">
                        <input :checked="statusTrash" type="checkbox" x-model="statusTrash">
                        <div class="checkmark"></div>
                    </label>
                    <label x-text="data?.trashLabel || labels.trash"></label>
                </div>
            </template>
        </div>
        <div class="dialog-form-footer" style="padding: 0px 30px 15px;width: 100%;">
            <button type="button" class="close" @click="$store?.confirmDialog?.close(false)"
                x-text="data?.btnClose || labels.close" x-bind:disabled="disabled || loading"
                style="margin-right: 10px;background: none !important;"></button>
            <button type="button" @click="onConfirm" x-bind:disabled="disabled || loading" :class="data?.btnSaveClass || ''" style="border-radius: 25px;">
                <span class='bx bx-loader-alt spinLoading bx-spin' x-show="loading"
                    style="margin-right: 10px;display: none;"></span>
                <span x-text="data?.btnSave || labels.save"></span>
            </button>
        </div>
    </div>
    </template>
    <script>
        var verifyConfirmDialogDefinition = () => ({
            data: null,
            labels: {
                trash: @json(__('dialog.button.move_to_trash')),
                close: @json(__('global.button.close')),
                save: @json(__('global.button.save')),
                requestFailed: @json(__('global.message.request_failed')),
            },
            disabled: false,
            loading: false,
            statusTrash: true,
            urlRute: "#",
            typeAction: "",
            init() {
                this.data = this.$store?.confirmDialog?.data ?? null;
                this.typeAction = this.data?.typeAction || '';
                this.funStatusTrash(url => { this.urlRute = url });
            },
            funStatusTrash(cb) {
                this.data = this.$store?.confirmDialog?.data ?? this.data;
                this.typeAction = this.data?.typeAction || this.typeAction;
                if (!this.data) {
                    if (cb) cb('#');
                    return;
                }
                if (this.data?.url) {
                    cb(this.data.url);
                    return;
                }
                let Status = this.data?.item?.status == 1 ? 2 : 1;
                const urlDelete = `/admin/${this.data?.urlName || ''}/delete/${this.data?.item?.id || ''}`;
                const urlDestory = `/admin/${this.data?.urlName || ''}/destroy/${this.data?.item?.id || ''}`;
                const urlRestore = `/admin/${this.data?.urlName || ''}/restore/${this.data?.item?.id || ''}`;
                const urlStatus = `/admin/${this.data?.urlName || ''}/status/${this.data?.item?.id || ''}/${Status}`;
                let urlRute = "";
                if (this.typeAction == 'restore') {
                    urlRute = urlRestore;
                } else if (this.typeAction == 'delete') {
                    urlRute = this.statusTrash ? urlDelete : urlDestory;
                } else if (this.typeAction == 'destroy') {
                    urlRute = urlDestory;
                } else if (this.typeAction == 'status') {
                    urlRute = urlStatus;
                }
                cb(urlRute);
            },
            notifyError(message) {
                if (typeof this.data?.onError === 'function') {
                    this.data.onError(message);
                } else {
                    alert(message);
                }
            },
            onConfirm() {
                this.data = this.$store?.confirmDialog?.data ?? this.data;
                this.typeAction = this.data?.typeAction || this.typeAction;
                if (this.typeAction == 'manual' || (!this.data?.url && !this.data?.item && !this.data?.urlName)) {
                    this.$store?.confirmDialog?.close(true);
                    return;
                }

                this.funStatusTrash(url => {
                    if (!url || url === '#' || url === '') {
                        this.$store?.confirmDialog?.close(true);
                        return;
                    }

                    this.disabled = true;
                    this.loading = true;

                    setTimeout(async () => {
                        Axios({
                            url: url,
                            method: this.data?.method || 'POST',
                            data: {
                                _token: '{{ csrf_token() }}',
                                ...this.data?.item,
                                ...(this.data?.postData || {})
                            }
                        }).then((res) => {
                            if (res.data.message == "success" || res.data.status == 200) {
                                this.$store?.confirmDialog?.close(true);
                            } else {
                                const message = res.data?.error || res.data?.message || this.data?.requestFailed || this.labels.requestFailed;
                                this.notifyError(message);
                                this.disabled = false;
                                this.loading = false;
                            }
                        }).catch((e) => {
                            this.validate = e.response?.data?.errors;
                            const message = e.response?.data?.error ||
                                Object.values(e.response?.data?.errors || {})?.[0]?.[0] ||
                                this.data?.requestFailed || this.labels.requestFailed;
                            this.notifyError(message);
                            this.disabled = false;
                            this.loading = false;
                        }).finally(() => {
                            this.disabled = false;
                            this.loading = false;
                        });
                    }, 500);
                });
            }
        });
        if (window.Alpine) {
            Alpine.data("verifyConfirmDialog", verifyConfirmDialogDefinition);
            Alpine.data("confirmDialog", verifyConfirmDialogDefinition);
        } else {
            document.addEventListener('alpine:init', () => {
                Alpine.data("verifyConfirmDialog", verifyConfirmDialogDefinition);
                Alpine.data("confirmDialog", verifyConfirmDialogDefinition);
            });
        }
    </script>
@endcomponent
@endif
