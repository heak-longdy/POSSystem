@extends('admin::shared.layout')
@section('layout')
    @include('admin::shared.header', ['header_name' => __('shop.product.title')])
    <div class="content-wrapper" id="app" x-data="xShopProductListing">
        <div class="header box-shadow-bottom">
            <div class="header-tab">
                <div class="header-tab-wrapper">
                    <div class="menu-row">
                        <div class="tabs">
                            <a href="{!! route('admin-' . $routeName . '-list', 1) !!}">
                                <i class='bx bx-store'></i>
                                {{ __('shop.tab.shop') }}
                            </a>
                            <a href="{!! route('admin-' . $routeName . '-product', $id) !!}" class="{!! $status != 'trash' ? 'tabActive' : '' !!}">
                                <i class='bx bx-package'></i>
                                {{ __('shop.tab.product') }}
                            </a>
                            <a href="{!! route('admin-' . $routeName . '-product', ['id' => $id, 'status' => 'trash']) !!}" class="{!! $status == 'trash' ? 'tabActive' : '' !!}">
                                <i class='bx bx-trash-alt'></i>
                                {{ __('global.tab.trash') }}
                            </a>
                        </div>
                    </div>
                </div>
                <div class="header-action-button">
                    <form class="filter" action="{!! url()->current() !!}" method="GET">
                        <div class="form-row w200">
                            <input type="text" name="search" placeholder="{{ __('global.filter.search') }}" value="{{ request('search') }}">
                        </div>
                        <button mat-flat-button type="submit" class="bg-success btnSearch">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                            </svg>
                        </button>
                    </form>
                    <button s-click-link="{!! url()->current() !!}">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
                        </svg>
                        <span>{{ __('global.button.reload') }}</span>
                    </button>
                    @if ($status != 'trash' && auth()->user()->can('shop-product'))
                        <button class="btn btn-create" s-click-link="{!! route('admin-' . $routeName . '-product-create', $id) !!}">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            <span>{{ __('shop.button.add_product') }}</span>
                        </button>
                    @endif
                </div>
            </div>
        </div>

        <div class="content-body">
            <div class="table">
                @if ($products->count() > 0)
                    <div class="table-wrapper">
                        <div class="paginationLayout2">
                            @include('admin::components.pagination', ['paginate' => $products])
                        </div>
                        <div class="table-header">
                            <div class="row table-row-5"><span>{{ __('shop.table.no') }}</span></div>
                            <div class="row table-row-10 text left"><span>{{ __('shop.table.image') }}</span></div>
                            <div class="row table-row-12 text left"><span>{{ __('shop.table.code') }}</span></div>
                            <div class="row table-row-20 text left"><span>{{ __('shop.table.product') }}</span></div>
                            <div class="row table-row-15 text left"><span>{{ __('shop.table.category') }}</span></div>
                            <div class="row table-row-10 text left"><span>{{ __('shop.table.uom') }}</span></div>
                            <div class="row table-row-13"><span>{{ __('shop.table.price') }}</span></div>
                            <div class="row table-row-10"><span>{{ __('shop.table.status') }}</span></div>
                            <div class="row table-row-5"><span></span></div>
                        </div>
                        <div class="table-body">
                            @foreach ($products as $index => $item)
                                <div class="column">
                                    <div class="row table-row-5">
                                        <span>{!! $products->currentPage() * $products->perPage() - $products->perPage() + ($index + 1) !!}</span>
                                    </div>
                                    <div class="row table-row-10 text left">
                                        @php
                                            $shopProductImg = $item->product?->image_url;
                                            $defaultImg = asset('images/logo/default.png');
                                            $shopProductDisplay = !empty($shopProductImg) ? $shopProductImg : $defaultImg;
                                            $hasRealImage = !empty($shopProductImg);
                                        @endphp
                                        <div class="thumbnail" data-fancybox data-src="{!! $shopProductImg ?: $defaultImg !!}">
                                            <div class="product-image-wrapper" {!! $hasRealImage ? 'data-detect-bg="1"' : '' !!}>
                                                <img src="{!! $shopProductDisplay !!}"
                                                    onerror="this.onerror=null;this.src='{{ $defaultImg }}';this.closest('.product-image-wrapper').removeAttribute('data-detect-bg');"
                                                    alt="" class="product-image-main"
                                                    {!! $hasRealImage ? 'crossorigin="anonymous"' : '' !!}>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row table-row-12 text left">
                                        <span>{{ $item->product?->code ?? '---' }}</span>
                                    </div>
                                    <div class="row table-row-20 text left">
                                        <span>{{ $item->product?->name ?? '---' }}</span>
                                    </div>
                                    <div class="row table-row-15 text left">
                                        <span>{{ $item->product?->category?->name ?? '---' }}</span>
                                    </div>
                                    <div class="row table-row-10 text left">
                                        <span>{{ $item->product?->uom?->name ?? '---' }}</span>
                                    </div>
                                    <div class="row table-row-13">
                                        <span>{{ $item->price !== null ? number_format($item->price, 2) . ' $' : '---' }}</span>
                                    </div>
                                    <div class="row table-row-10">
                                        <span>{{ $item->status == 1 ? __('global.tab.active') : ($item->status == 2 ? __('global.tab.disable') : '---') }}</span>
                                    </div>
                                    <div class="row table-row-5">
                                        <div class="dropdown">
                                            <i data-feather="more-vertical" class="action-btn" id="dropdownMenuButton"
                                                data-mdb-toggle="dropdown" aria-expanded="false">
                                            </i>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                @if ($status != 'trash')
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="{!! route('admin-' . $routeName . '-product-edit', ['shopId' => $id, 'shopProductId' => $item->id]) !!}">
                                                            <i class="material-symbols-outlined">edit</i>
                                                            <span>{{ __('shop.action.edit') }}</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item text-danger"
                                                            @click="verifyDialog({{ $item }},'delete','@lang('action_button.delete')')">
                                                            <i class="material-symbols-outlined">Delete</i>
                                                            <span>{{ __('shop.action.delete') }}</span>
                                                        </a>
                                                    </li>
                                                @else
                                                    <li>
                                                        <a class="dropdown-item"
                                                            @click="verifyDialog({{ $item }},'restore','@lang('action_button.restore')')">
                                                            <i class="material-symbols-outlined">settings_backup_restore</i>
                                                            <span>{{ __('shop.action.restore') }}</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item text-danger"
                                                            @click="verifyDialog({{ $item }},'destroy','@lang('action_button.destroy')')">
                                                            <i class="material-symbols-outlined">Delete</i>
                                                            <span>{{ __('shop.action.destroy') }}</span>
                                                        </a>
                                                    </li>
                                                @endif
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="paginationLayout">
                            @include('admin::components.paginationNumber', ['paginate' => $products])
                        </div>
                    </div>
                @else
                    @component('admin::components.empty', [
                        'name' => $status == 'trash' ? __('shop.empty.trash_title') : __('shop.empty.title'),
                        'msg' => $status == 'trash' ? __('shop.empty.trash_description') : __('shop.empty.description'),
                        'url' => $status == 'trash' ? null : route('admin-' . $routeName . '-product-create', $id),
                        'button' => $status == 'trash' ? null : __('shop.button.add_product'),
                        'permission' => 'shop-product',
                    ])
                    @endcomponent
                @endif
            </div>
        </div>
    </div>
@stop

@section('script')
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('xShopProductListing', () => ({
                verifyDialog(data, typeAction, btn) {
                    const confirmTemplate = `{{ __('shop.dialog.confirm_action', ['action' => '__ACTION__']) }}`;
                    const confirmMsg = confirmTemplate.replace('__ACTION__', btn);
                    this.$store.confirmDialog.open({
                        data: {
                            message: confirmMsg,
                            btnClose: `{{ __('action_button.cancel') }}`,
                            btnSave: btn,
                            item: data,
                            urlName: `shop/product/{{ $id }}`,
                            typeAction: typeAction,
                            digPosition: "posTop",
                            class: "deleteDialog",
                            width: "18rem"
                        },
                        afterClosed: (result) => {
                            if (result) {
                                window.location.href = `{{ url()->full() }}`;
                            }
                        }
                    });
                },
            }))
        });
    </script>
@stop
