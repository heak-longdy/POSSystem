@extends('admin::shared.layout')
@section('layout')
    @include('admin::shared.header', ['header_name' => __('product.title')])
    <div class="content-wrapper" id="app" x-data="xIndex">
        @component('admin::components.listingData', [
            'routeName' => $routeName,
            'createName' => __('product.button.create'),
            'filterStatus' => true,
            'exportUrl' => $exportUrl ?? '',
            'data' => $data,
            'status' => $status,
            'tabs' => [
                [
                    'url' => route('admin-' . $routeName . '-list', 1),
                    'active' => Request::is('admin/' . $routeName . '/list/1'),
                    'icon' => 'bx bx-data',
                    'label' => __('global.tab.active'),
                ],
                [
                    'url' => route('admin-' . $routeName . '-list', 2),
                    'active' => Request::is('admin/' . $routeName . '/list/2'),
                    'icon' => 'bx bx-navigation',
                    'label' => __('global.tab.disable'),
                ],
                [
                    'url' => route('admin-' . $routeName . '-list', 'trash'),
                    'active' => Request::is('admin/' . $routeName . '/list/trash'),
                    'icon' => 'bx bx-trash-alt',
                    'label' => __('global.tab.trash'),
                ],
            ],
            'tbHeader' => [
                ['field' => 'index', 'title' => __('global.table.no'), 'class' => '', 'colVal' => 5],
                ['field' => 'image_url', 'title' => __('global.table.image'), 'class' => 'text left', 'colVal' => 10],
                ['field' => 'name', 'title' => __('global.table.name'), 'class' => 'text left', 'colVal' => 25],
                ['field' => 'category_title', 'title' => __('global.table.category'), 'class' => 'text left', 'colVal' => 15],
                ['field' => 'uom_title', 'title' => __('global.table.uom'), 'class' => 'text left', 'colVal' => 10],
                ['field' => 'CostUsdFor', 'title' => __('global.table.cost'), 'class' => 'text left', 'colVal' => 15],
                ['field' => 'PriceUsdFor', 'title' => __('global.table.price'), 'class' => 'text left', 'colVal' => 15],
                [
                    'field' => 'action',
                    'title' => "",
                    'class' => '',
                    'colVal' => 5,
                    'actions' => [
                        [
                            'key' => 'active',
                            'action' => [
                                ['url' => 'edit', 'title' => __('global.action.edit'), 'icon' => 'edit', 'type' => 'link'],
                                [
                                    'url' => 'delete',
                                    'title' => __('global.action.delete'),
                                    'icon' => 'Delete',
                                    'class' => 'text-danger',
                                ],
                            ],
                        ],
                        [
                            'key' => 'disable',
                            'action' => [
                                [
                                    'url' => 'status',
                                    'title' => __('global.action.disable'),
                                    'icon' => 'hide_source',
                                    'class' => 'text-danger',
                                ],
                            ],
                        ],
                        [
                            'key' => 'enable',
                            'action' => [['url' => 'status', 'title' => __('global.action.enable'), 'icon' => 'refresh']],
                        ],
                        [
                            'key' => 'trash',
                            'action' => [
                                [
                                    'url' => 'restore',
                                    'title' => __('global.action.restore'),
                                    'icon' => 'settings_backup_restore',
                                ],
                                [
                                    'url' => 'destroy',
                                    'title' => __('global.action.destroy'),
                                    'icon' => 'Delete',
                                    'class' => 'text-danger',
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ])
        @endcomponent
    </div>
@stop

@section('script')
    <script lang="ts">
        (function() {
            const registerXIndex = () => {
                Alpine.data('xIndex', () => ({
                    loading: null,
                    selected_id: null,
                    groupClassList: [],
                    professionList: [],
                    async init() {
                        this.loading = true;
                        this.loading = false;
                    },
                    async fetchData(url, callback) {
                        await fetch(url, {
                                method: "GET",
                                headers: {
                                    "Content-Type": "application/json",
                                    "Accept": "application/json",
                                }
                            })
                            .then(response => response.json())
                            .then(response => {
                                callback(response);
                            })
                            .catch((e) => {})
                            .finally(async (res) => {});
                    },
                    storeDialog(data = null, type = null) {
                        this.$store?.store?.open({
                            data: data,
                            type: type
                        });
                    },
                    verifyDialog(data, typeAction, btn) {
                        const confirmTemplate = `{{ __('global.dialog.confirm_action', ['action' => '__ACTION__']) }}`;
                        const confirmMsg = confirmTemplate.replace('__ACTION__', btn);
                        this.$store?.confirmDialog?.open({
                            data: {
                                message: confirmMsg,
                                btnClose: `{{ __('action_button.cancel') }}`,
                                btnSave: btn,
                                trashLabel: @json(__('dialog.button.move_to_trash')),
                                item: data,
                                urlName:`{{$routeName}}`,
                                typeAction: typeAction,
                                digPosition: "posTop",
                                class: "deleteDialog",
                                width: "18rem"
                            },
                            afterClosed: (result) => {
                                if (result) {
                                    let Url = `{{ url()->full() }}`;
                                    reloadData(Url);
                                }
                            }
                        });
                    },
                }));
            };

            if (window.Alpine) {
                registerXIndex();
            } else {
                document.addEventListener('alpine:init', registerXIndex);
            }
        })();
    </script>
@stop
