<?php

namespace Database\Seeders;

use Database\Factories\OrderFactory;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UserSeeder::class,
            PermissionSeeder::class,
            ProductSeeder::class,
            StaffSeeder::class,
            CustomerSeeder::class,
            ShopSeeder::class,
            SupplierSeeder::class,
            //OrderSeeder::class
        ]);
    }
}
