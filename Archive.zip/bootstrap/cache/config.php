<?php return array (
  'adv-type' => 
  array (
    'type' => 
    array (
      'left' => 'Left',
      'right' => 'Right',
      'top' => 'Top',
      'bottom' => 'Bottom',
    ),
  ),
  'apiKey' => 
  array (
    'map_api_key' => 'AIzaSyAjb0Kjcybkg9juPpIDhcNbSwl_l_Zpib4',
    'apiLink' => 'http://127.0.0.1:8000/',
  ),
  'apiStatus' => 
  array (
    'limitPaginate' => 20,
    'limitData' => 15,
    'limitDataRelated' => 10,
    'selectProduct' => 
    array (
      0 => 'id',
      1 => 'store_id',
      2 => 'name',
      3 => 'description',
      4 => 'price',
      5 => 'discount',
      6 => 'qty_in_stock',
      7 => 'point_value',
      8 => 'allow_call',
      9 => 'allow_add_cart',
      10 => 'thumbnail',
      11 => 'type',
      12 => 'product_type',
    ),
    'selectStore' => 
    array (
      0 => 'id',
      1 => 'user_id',
      2 => 'name',
      3 => 'address',
      4 => 'description',
      5 => 'phone',
      6 => 'patent_number',
      7 => 'logo',
      8 => 'cover_image',
      9 => 'map',
      10 => 'qr_code',
      11 => 'type',
      12 => 'province_id',
      13 => 'district_id',
      14 => 'commune_id',
      15 => 'village_id',
    ),
    'selectBrand' => 
    array (
      0 => 'brands.id',
      1 => 'brands.parent_id',
      2 => 'brands.name',
      3 => 'brands.image',
      4 => 'brands.status',
      5 => 'brands.ordering',
    ),
    'selectCategory' => 
    array (
      0 => 'id',
      1 => 'parent_id',
      2 => 'name',
      3 => 'image',
      4 => 'type',
      5 => 'ordering',
    ),
    'selectJob' => 
    array (
      0 => 'id',
      1 => 'user_id',
      2 => 'store_id',
      3 => 'title',
      4 => 'category_id',
      5 => 'location_id',
      6 => 'view',
      7 => 'image',
      8 => 'year_experience',
      9 => 'is_negotiate',
      10 => 'salary_from',
      11 => 'salary_to',
      12 => 'job_type',
      13 => 'status',
      14 => 'description',
    ),
    'selectService' => 
    array (
      0 => 'id',
      1 => 'name',
      2 => 'price',
      3 => 'description',
      4 => 'discount',
      5 => 'qty_in_stock',
      6 => 'point_value',
      7 => 'image',
      8 => 'status',
      9 => 'user_id',
      10 => 'garage_id',
    ),
    'selectNotification' => 
    array (
      0 => 'id',
      1 => 'booking_id',
      2 => 'member_id',
      3 => 'garage_id',
      4 => 'title',
      5 => 'description',
      6 => 'type',
      7 => 'is_read_member',
      8 => 'is_read_garage',
      9 => 'status',
      10 => 'created_at',
    ),
  ),
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'google_map_key' => NULL,
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'Asia/Phnom_Penh',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:NmLFDQVhzc8waJXKr8IHeezssRnP+yj8AJrcSwqEO7I=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      23 => 'Spatie\\Permission\\PermissionServiceProvider',
      24 => 'Collective\\Html\\HtmlServiceProvider',
      25 => 'SimpleSoftwareIO\\QrCode\\QrCodeServiceProvider',
      26 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      27 => 'App\\Providers\\AppServiceProvider',
      28 => 'App\\Providers\\AuthServiceProvider',
      29 => 'App\\Providers\\EventServiceProvider',
      30 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'HTML' => 'Collective\\Html\\HtmlFacade',
      'DateFormat' => 'App\\Functions\\DateFormat',
      'QrCode' => 'SimpleSoftwareIO\\QrCode\\Facades\\QrCode',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Menu' => 'App\\Helper\\Menu',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'passport',
        'provider' => 'barbers',
      ),
      'barber-api' => 
      array (
        'driver' => 'passport',
        'provider' => 'barbers',
      ),
      'barber' => 
      array (
        'driver' => 'session',
        'provider' => 'barbers',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'barbers' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Barber',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'laravel_cache_',
  ),
  'cnst' => 
  array (
    'status' => 
    array (
      'active' => 1,
      'disable' => 2,
    ),
    'user_type' => 
    array (
      'admin' => 'Admin',
      'customer' => 'Customer',
      'store' => 'Store',
    ),
    'user_role' => 
    array (
      'admin' => 'Admin',
      'super_admin' => 'Super Admin',
      'user' => 'User',
    ),
    'order_status' => 
    array (
      1 => 'pending',
      2 => 'confirmed',
      3 => 'cancelled',
      4 => 'completed',
    ),
    'book_status' => 
    array (
      1 => 'pending',
      2 => 'confirmed',
      3 => 'cancelled',
      4 => 'completed',
    ),
    'type' => 
    array (
      'job' => 'Job',
      'hotel' => 'Hotel',
      'real_estate' => 'Real Estate',
      'general_product' => 'General Product',
    ),
    'job_types' => 
    array (
      'full-time' => 'Full-Time',
      'part-time' => 'Part-Time',
      'internships' => 'Internships',
      'freelance' => 'Freelance',
      'contract' => 'Contract',
      'volunteer' => 'Volunteer',
      'other' => 'Other',
    ),
    'facing_position' => 
    array (
      0 => 'east',
      1 => 'north',
      2 => 'northeast',
      3 => 'northwest',
      4 => 'southeast',
      5 => 'southwest',
      6 => 'west',
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'POSSystem',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'POSSystem',
        'username' => 'root',
        'password' => 'Longdy1234',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => 'InnoDB',
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'POSSystem',
        'username' => 'root',
        'password' => 'Longdy1234',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'POSSystem',
        'username' => 'root',
        'password' => 'Longdy1234',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
      'starts_with' => false,
    ),
    'index_column' => 'DT_RowIndex',
    'engines' => 
    array (
      'eloquent' => 'Yajra\\DataTables\\EloquentDataTable',
      'query' => 'Yajra\\DataTables\\QueryDataTable',
      'collection' => 'Yajra\\DataTables\\CollectionDataTable',
      'resource' => 'Yajra\\DataTables\\ApiResourceDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
    'callback' => 
    array (
      0 => '$',
      1 => '$.',
      2 => 'function',
    ),
  ),
  'dummy' => 
  array (
    'status' => 
    array (
      1 => 'Active',
      2 => 'Disable',
    ),
    'user' => 
    array (
      'role' => 
      array (
        'super_admin' => 'super_admin',
        'admin' => 'admin',
        'manager' => 'manager',
        'cashier' => 'cashier',
        'staff' => 'staff',
      ),
    ),
    'months' => 
    array (
      0 => 
      array (
        'id' => 1,
        'title' => 'January',
      ),
      1 => 
      array (
        'id' => 2,
        'title' => 'February',
      ),
      2 => 
      array (
        'id' => 3,
        'title' => 'March',
      ),
      3 => 
      array (
        'id' => 4,
        'title' => 'April',
      ),
      4 => 
      array (
        'id' => 5,
        'title' => 'May',
      ),
      5 => 
      array (
        'id' => 6,
        'title' => 'June',
      ),
      6 => 
      array (
        'id' => 7,
        'title' => 'July',
      ),
      7 => 
      array (
        'id' => 8,
        'title' => 'August',
      ),
      8 => 
      array (
        'id' => 9,
        'title' => 'September',
      ),
      9 => 
      array (
        'id' => 10,
        'title' => 'October',
      ),
      10 => 
      array (
        'id' => 11,
        'title' => 'November',
      ),
      11 => 
      array (
        'id' => 12,
        'title' => 'December',
      ),
    ),
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
        'output_encoding' => '',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => NULL,
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
      'db' => 
      array (
        'connection' => NULL,
      ),
    ),
    'temporary_files' => 
    array (
      'local_path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/framework/cache/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/public/uploads',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      '/Users/longdy/Documents/Projects/Laravel/POSSystem/public/storage' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/app/public',
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => true,
    'remote_sites_path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
  ),
  'languages' => 
  array (
    'default' => 'en',
    'fallback' => 'en',
    'supported' => 
    array (
      'en' => 
      array (
        'name' => 'English',
        'native_name' => 'English',
        'direction' => 'ltr',
        'active' => true,
      ),
      'km' => 
      array (
        'name' => 'Khmer',
        'native_name' => 'ខ្មែរ',
        'direction' => 'ltr',
        'active' => true,
      ),
    ),
  ),
  'lara-izitoast' => 
  array (
    'titleColor' => '',
    'messageColor' => '',
    'titleSize' => '38',
    'messageSize' => '38',
    'titleLineHeight' => '38',
    'messageLineHeight' => '38',
    'transitionIn' => 'flipInX',
    'transitionOut' => 'flipOutX',
    'zindex' => NULL,
    'closeOnClick' => true,
    'timeout' => 5000,
    'drag' => true,
    'position' => 'bottomRight',
    'progressBar' => true,
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Http\\Livewire',
    'view_path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/resources/views/livewire',
    'layout' => 'layouts.app',
    'asset_url' => NULL,
    'app_url' => NULL,
    'middleware_group' => 'web',
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
    ),
    'manifest_path' => NULL,
    'back_button_cache' => false,
    'render_on_redirect' => false,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'log_channel' => 'stack',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.mailgun.org',
        'port' => 587,
        'encryption' => 'tls',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/Users/longdy/Documents/Projects/Laravel/POSSystem/resources/views/vendor/mail',
      ),
    ),
  ),
  'mailSend' => 
  array (
    'applyJob' => 'longdy@longdydevopsinfo.com',
    'contact' => 'longdy@longdydevopsinfo.com',
  ),
  'menu' => 
  array (
    0 => 
    array (
      'type' => 'single',
      'active' => 'admin/product/*',
      'path' => 'admin/product/list/1',
      'permission' => 
      array (
        0 => 'product-view',
      ),
      'name' => 
      array (
        'en' => 'Product',
        'km' => 'ផលិតផល',
      ),
      'icon' => 'bx-package',
    ),
    1 => 
    array (
      'type' => 'single',
      'active' => 'admin/order/*',
      'path' => 'admin/order/list/1',
      'permission' => 
      array (
        0 => 'order-view',
      ),
      'name' => 
      array (
        'en' => 'Orders',
        'km' => 'ការបញ្ជាទិញ',
      ),
      'icon' => 'bx-calendar',
    ),
    2 => 
    array (
      'type' => 'single',
      'active' => 'admin/remaining-amount/*',
      'path' => 'admin/remaining-amount/list/partial',
      'permission' => 'order-view',
      'name' => 
      array (
        'en' => 'Remaining Amount',
        'km' => 'គ្រប់គ្រងទឹកប្រាក់នៅសល់',
      ),
      'icon' => 'bx-wallet',
    ),
    3 => 
    array (
      'type' => 'single',
      'active' => 'admin/shop/*',
      'path' => 'admin/shop/list/1',
      'permission' => 
      array (
        0 => 'shop-view',
      ),
      'name' => 
      array (
        'en' => 'Shop',
        'km' => 'ហាង',
      ),
      'icon' => 'bx-store-alt',
    ),
    4 => 
    array (
      'type' => 'single',
      'active' => 'admin/customer/*',
      'path' => 'admin/customer/list/1',
      'permission' => 
      array (
        0 => 'customer-view',
      ),
      'name' => 
      array (
        'en' => 'Customer',
        'km' => 'អតិថិជន',
      ),
      'icon' => 'bx-user',
    ),
    5 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Inventory Management',
        'km' => 'ការគ្រប់គ្រងស្តុក',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-in/*',
          'path' => 'admin/stock-in/list/1',
          'permission' => 
          array (
            0 => 'stock-in-view',
          ),
          'name' => 
          array (
            'en' => 'Stock In',
            'km' => 'ការបញ្ចូលស្តុក',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-out/*',
          'path' => 'admin/stock-out/list/1',
          'permission' => 
          array (
            0 => 'stock-out-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Out',
            'km' => 'ការដកស្តុក',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-transfer/*',
          'path' => 'admin/stock-transfer/list/1',
          'permission' => 
          array (
            0 => 'stock-transfer-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Transfer',
            'km' => 'ការផ្ទេរស្តុក',
          ),
          'icon' => 'bxl-redux',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-on-hand/*',
          'path' => 'admin/stock-on-hand/list/1',
          'permission' => 
          array (
            0 => 'stock-on-hand-view',
          ),
          'name' => 
          array (
            'en' => 'Stock On Hand',
            'km' => 'ស្តុកដែលមាន',
          ),
          'icon' => 'bx-infinite',
          'dropDown' => 'disable',
        ),
        4 => 
        array (
          'active' => 'admin/stock-movement/*',
          'path' => 'admin/stock-movement/list/1',
          'permission' => 
          array (
            0 => 'stock-movement-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Movement',
            'km' => 'ការផ្លាស់ប្ដូរស្តុក',
          ),
          'icon' => 'bx-user',
          'dropDown' => 'disable',
          'children' => 
          array (
          ),
        ),
      ),
    ),
    6 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Report Management',
        'km' => 'ការគ្រប់គ្រងរបាយការណ៍',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/order-transaction*',
          'path' => 'admin/report/order-transaction/daily',
          'permission' => 
          array (
            0 => 'report-transaction-view',
            1 => 'report-sales-view',
            2 => 'order-view',
          ),
          'name' => 
          array (
            'en' => 'Order Transaction Report',
            'km' => 'របាយការណ៍ប្រតិបត្តិការបញ្ជាទិញ',
          ),
          'icon' => 'bx-receipt',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/sales*',
          'path' => 'admin/report/sales/daily',
          'permission' => 
          array (
            0 => 'report-sales-view',
            1 => 'order-view',
          ),
          'name' => 
          array (
            'en' => 'Sales Report',
            'km' => 'របាយការណ៍ការលក់',
          ),
          'icon' => 'bx-bar-chart-alt-2',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/customer-remaining-amount*',
          'path' => 'admin/report/customer-remaining-amount',
          'permission' => 
          array (
            0 => 'report-sales-view',
            1 => 'order-view',
          ),
          'name' => 
          array (
            'en' => 'Customer Remaining Amount Report',
            'km' => 'របាយការណ៍ទឹកប្រាក់នៅសល់របស់អតិថិជន',
          ),
          'icon' => 'bx-wallet',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/inventory-movement*',
          'path' => 'admin/report/inventory-movement/daily',
          'permission' => 
          array (
            0 => 'report-inventory-view',
            1 => 'stock-movement-view',
            2 => 'report-sales-view',
          ),
          'name' => 
          array (
            'en' => 'Inventory Movement Report',
            'km' => 'របាយការណ៍បម្រែបម្រួលស្តុក',
          ),
          'icon' => 'bx-transfer-alt',
          'dropDown' => 'disable',
        ),
        4 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/staff-expense*',
          'path' => 'admin/report/staff-expense/daily',
          'permission' => 
          array (
            0 => 'staff-expense-view',
            1 => 'report-sales-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Expense Report',
            'km' => 'របាយការណ៍ចំណាយបុគ្គលិក',
          ),
          'icon' => 'bx-wallet-alt',
          'dropDown' => 'disable',
        ),
      ),
    ),
    7 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Setting & Application',
        'km' => 'ការកំណត់ និងកម្មវិធី',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/position/*',
          'path' => 'admin/position/list/1',
          'permission' => 
          array (
            0 => 'position-view',
          ),
          'name' => 
          array (
            'en' => 'Position',
            'km' => 'មុខតំណែង',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/staff/*',
          'path' => 'admin/staff/list/1',
          'permission' => 
          array (
            0 => 'staff-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Management',
            'km' => 'ការគ្រប់គ្រងបុគ្គលិក',
          ),
          'icon' => 'bx-group',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/staff-expense*',
          'path' => 'admin/staff-expense/list/1',
          'permission' => 
          array (
            0 => 'staff-expense-view',
            1 => 'staff-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Expenses',
            'km' => 'ចំណាយបុគ្គលិក',
          ),
          'icon' => 'bx-dollar-circle',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'active' => 'admin/user/*',
          'path' => 'admin/user/list/1',
          'permission' => 'user-view',
          'name' => 
          array (
            'en' => 'User Management',
            'km' => 'ការគ្រប់គ្រងអ្នកប្រើប្រាស់',
          ),
          'icon' => 'bx-user',
          'dropDown' => 'disable',
          'children' => 
          array (
          ),
        ),
        4 => 
        array (
          'type' => 'single',
          'active' => 'admin/file-manager/*',
          'path' => 'admin/file-manager/index',
          'name' => 
          array (
            'en' => 'File Manager',
            'km' => 'គ្រប់គ្រងឯកសារ',
          ),
          'icon' => 'bx-folder',
          'dropDown' => 'disable',
        ),
        5 => 
        array (
          'active' => 'admin/about/privacy*,admin/aboutUs*,admin/uom/*,admin/category/*,admin/supplier/*,admin/setting/invoice*',
          'permission' => 
          array (
            0 => 'about-view',
            1 => 'uom-view',
          ),
          'name' => 
          array (
            'en' => 'Setting',
            'km' => 'ការកំណត់',
          ),
          'icon' => 'bx-wrench',
          'children' => 
          array (
            0 => 
            array (
              'active' => 'admin/category/*',
              'path' => 'admin/category/list/1',
              'permission' => 'category-view',
              'name' => 
              array (
                'en' => 'Category',
                'km' => 'ប្រភេទ',
              ),
              'icon' => 'bx-category',
            ),
            1 => 
            array (
              'active' => 'admin/supplier/*',
              'path' => 'admin/supplier/list/1',
              'permission' => 'supplier-view',
              'name' => 
              array (
                'en' => 'Supplier',
                'km' => 'អ្នកផ្គត់ផ្គង់',
              ),
              'icon' => 'bx-ruler',
            ),
            2 => 
            array (
              'active' => 'admin/uom/*',
              'path' => 'admin/uom/list/1',
              'permission' => 'uom-view',
              'name' => 
              array (
                'en' => 'Unit of Measure',
                'km' => 'ខ្នាត',
              ),
              'icon' => 'bx-ruler',
            ),
            3 => 
            array (
              'active' => 'admin/setting/invoice*',
              'path' => 'admin/setting/invoice',
              'name' => 
              array (
                'en' => 'Invoice Setting',
                'km' => 'ការកំណត់វិក្កយបត្រ',
              ),
              'icon' => 'bx-receipt',
            ),
          ),
        ),
      ),
    ),
  ),
  'menu copy' => 
  array (
    0 => 
    array (
      'type' => 'single',
      'active' => 'admin/product/*',
      'path' => 'admin/product/list/1',
      'permission' => 
      array (
        0 => 'product-view',
      ),
      'name' => 
      array (
        'en' => 'Product',
        'km' => 'ផលិតផល',
      ),
      'icon' => 'bx-package',
    ),
    1 => 
    array (
      'type' => 'single',
      'active' => 'admin/order/*',
      'path' => 'admin/order/list/1',
      'permission' => 
      array (
        0 => 'order-view',
      ),
      'name' => 
      array (
        'en' => 'Orders',
        'km' => 'ការបញ្ជាទិញ',
      ),
      'icon' => 'bx-calendar',
    ),
    2 => 
    array (
      'type' => 'single',
      'active' => 'admin/remaining-amount/*',
      'path' => 'admin/remaining-amount/list/all',
      'permission' => 'order-view',
      'name' => 
      array (
        'en' => 'Remaining Amount',
        'km' => 'គ្រប់គ្រងទឹកប្រាក់នៅសល់',
      ),
      'icon' => 'bx-wallet',
    ),
    3 => 
    array (
      'type' => 'single',
      'active' => 'admin/shop/*',
      'path' => 'admin/shop/list/1',
      'permission' => 
      array (
        0 => 'shop-view',
      ),
      'name' => 
      array (
        'en' => 'Shop',
        'km' => 'ហាង',
      ),
      'icon' => 'bx-store-alt',
    ),
    4 => 
    array (
      'type' => 'single',
      'active' => 'admin/customer/*',
      'path' => 'admin/customer/list/1',
      'permission' => 
      array (
        0 => 'customer-view',
      ),
      'name' => 
      array (
        'en' => 'Customer',
        'km' => 'អតិថិជន',
      ),
      'icon' => 'bx-user',
    ),
    5 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Inventory Management',
        'km' => 'ការគ្រប់គ្រងស្តុក',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-in/*',
          'path' => 'admin/stock-in/list/1',
          'permission' => 
          array (
            0 => 'stock-in-view',
          ),
          'name' => 
          array (
            'en' => 'Stock In',
            'km' => 'ការបញ្ចូលស្តុក',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-out/*',
          'path' => 'admin/stock-out/list/1',
          'permission' => 
          array (
            0 => 'stock-out-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Out',
            'km' => 'ការដកស្តុក',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-transfer/*',
          'path' => 'admin/stock-transfer/list/1',
          'permission' => 
          array (
            0 => 'stock-transfer-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Transfer',
            'km' => 'ការផ្ទេរស្តុក',
          ),
          'icon' => 'bxl-redux',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'type' => 'single',
          'active' => 'admin/stock-on-hand/*',
          'path' => 'admin/stock-on-hand/list/1',
          'permission' => 
          array (
            0 => 'stock-on-hand-view',
          ),
          'name' => 
          array (
            'en' => 'Stock On Hand',
            'km' => 'ស្តុកដែលមាន',
          ),
          'icon' => 'bx-infinite',
          'dropDown' => 'disable',
        ),
        4 => 
        array (
          'active' => 'admin/stock-movement/*',
          'path' => 'admin/stock-movement/list/1',
          'permission' => 
          array (
            0 => 'stock-movement-view',
          ),
          'name' => 
          array (
            'en' => 'Stock Movement',
            'km' => 'ការផ្លាស់ប្ដូរស្តុក',
          ),
          'icon' => 'bx-user',
          'dropDown' => 'disable',
          'children' => 
          array (
          ),
        ),
      ),
    ),
    6 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Report Management',
        'km' => 'ការគ្រប់គ្រងរបាយការណ៍',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/order-transaction*',
          'path' => 'admin/report/order-transaction/daily',
          'permission' => 
          array (
            0 => 'report-transaction-view',
            1 => 'report-sales-view',
            2 => 'order-view',
          ),
          'name' => 
          array (
            'en' => 'Order Transaction Report',
            'km' => 'របាយការណ៍ប្រតិបត្តិការបញ្ជាទិញ',
          ),
          'icon' => 'bx-receipt',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/sales*',
          'path' => 'admin/report/sales/daily',
          'permission' => 
          array (
            0 => 'report-sales-view',
            1 => 'order-view',
          ),
          'name' => 
          array (
            'en' => 'Sales Report',
            'km' => 'របាយការណ៍ការលក់',
          ),
          'icon' => 'bx-bar-chart-alt-2',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/inventory-movement*',
          'path' => 'admin/report/inventory-movement/daily',
          'permission' => 
          array (
            0 => 'report-inventory-view',
            1 => 'stock-movement-view',
            2 => 'report-sales-view',
          ),
          'name' => 
          array (
            'en' => 'Inventory Movement Report',
            'km' => 'របាយការណ៍បម្រែបម្រួលស្តុក',
          ),
          'icon' => 'bx-transfer-alt',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'type' => 'single',
          'active' => 'admin/report/staff-expense*',
          'path' => 'admin/report/staff-expense/daily',
          'permission' => 
          array (
            0 => 'staff-expense-view',
            1 => 'report-sales-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Expense Report',
            'km' => 'របាយការណ៍ចំណាយបុគ្គលិក',
          ),
          'icon' => 'bx-wallet-alt',
          'dropDown' => 'disable',
        ),
      ),
    ),
    7 => 
    array (
      'type' => 'dropdown-multiple',
      'label' => 
      array (
        'en' => 'Setting & Application',
        'km' => 'ការកំណត់ និងកម្មវិធី',
      ),
      'listMenu' => 
      array (
        0 => 
        array (
          'type' => 'single',
          'active' => 'admin/position/*',
          'path' => 'admin/position/list/1',
          'permission' => 
          array (
            0 => 'position-view',
          ),
          'name' => 
          array (
            'en' => 'Position',
            'km' => 'មុខតំណែង',
          ),
          'icon' => 'bx-universal-access',
          'dropDown' => 'disable',
        ),
        1 => 
        array (
          'type' => 'single',
          'active' => 'admin/staff/*',
          'path' => 'admin/staff/list/1',
          'permission' => 
          array (
            0 => 'staff-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Management',
            'km' => 'ការគ្រប់គ្រងបុគ្គលិក',
          ),
          'icon' => 'bx-group',
          'dropDown' => 'disable',
        ),
        2 => 
        array (
          'type' => 'single',
          'active' => 'admin/staff-expense*',
          'path' => 'admin/staff-expense/list/1',
          'permission' => 
          array (
            0 => 'staff-expense-view',
            1 => 'staff-view',
          ),
          'name' => 
          array (
            'en' => 'Staff Expenses',
            'km' => 'ចំណាយបុគ្គលិក',
          ),
          'icon' => 'bx-dollar-circle',
          'dropDown' => 'disable',
        ),
        3 => 
        array (
          'type' => 'single',
          'active' => 'admin/sector/*',
          'path' => 'admin/sector/list/1',
          'permission' => 
          array (
            0 => 'sector-view',
          ),
          'name' => 
          array (
            'en' => 'Sector',
            'km' => 'ផ្នែក',
          ),
          'icon' => 'bx-compass',
          'dropDown' => 'disable',
        ),
        4 => 
        array (
          'type' => 'single',
          'active' => 'admin/partner/*',
          'path' => 'admin/partner/list/1',
          'permission' => 
          array (
            0 => 'partner-view',
          ),
          'name' => 
          array (
            'en' => 'Partner',
            'km' => 'ដៃគូ',
          ),
          'icon' => 'bxl-redux',
          'dropDown' => 'disable',
        ),
        5 => 
        array (
          'type' => 'single',
          'active' => 'admin/placement-type/*',
          'path' => 'admin/placement-type/list/1',
          'permission' => 
          array (
            0 => 'placement-type-view',
          ),
          'name' => 
          array (
            'en' => 'Placement Type',
            'km' => 'ប្រភេទការដាក់ទីតាំង',
          ),
          'icon' => 'bx-badge-check',
          'dropDown' => 'disable',
        ),
        6 => 
        array (
          'active' => 'admin/user/*',
          'path' => 'admin/user/list/1',
          'permission' => 'user-view',
          'name' => 
          array (
            'en' => 'User Management',
            'km' => 'ការគ្រប់គ្រងអ្នកប្រើប្រាស់',
          ),
          'icon' => 'bx-user',
          'dropDown' => 'disable',
          'children' => 
          array (
          ),
        ),
        7 => 
        array (
          'active' => 'admin/contact*,admin/about/privacy*,admin/OurService*,admin/aboutUs*,admin/uom/*,admin/category/*,admin/supplier/*,admin/setting/invoice*',
          'permission' => 
          array (
            0 => 'contact-view',
            1 => 'about-view',
            2 => 'uom-view',
          ),
          'name' => 
          array (
            'en' => 'Setting',
            'km' => 'ការកំណត់',
          ),
          'icon' => 'bx-wrench',
          'children' => 
          array (
            0 => 
            array (
              'path' => 'admin/OurService',
              'active' => 'admin/OurService',
              'permission' => 'our-service-view',
              'name' => 
              array (
                'en' => 'Our Service',
                'km' => 'សេវាកម្មរបស់យើង',
              ),
              'icon' => 'bx-server',
            ),
            1 => 
            array (
              'path' => 'admin/contact',
              'active' => 'admin/contact',
              'permission' => 'contact-view',
              'name' => 
              array (
                'en' => 'Contact',
                'km' => 'ទំនាក់ទំនង',
              ),
              'icon' => 'bx-book',
            ),
            2 => 
            array (
              'path' => 'admin/aboutUs',
              'active' => 'admin/aboutUs',
              'permission' => 'about-view',
              'name' => 
              array (
                'en' => 'About',
                'km' => 'អំពីយើង',
              ),
              'icon' => 'bx-help-circle',
            ),
            3 => 
            array (
              'active' => 'admin/category/*',
              'path' => 'admin/category/list/1',
              'permission' => 'category-view',
              'name' => 
              array (
                'en' => 'Category',
                'km' => 'ប្រភេទ',
              ),
              'icon' => 'bx-category',
            ),
            4 => 
            array (
              'active' => 'admin/supplier/*',
              'path' => 'admin/supplier/list/1',
              'permission' => 'supplier-view',
              'name' => 
              array (
                'en' => 'Supplier',
                'km' => 'អ្នកផ្គត់ផ្គង់',
              ),
              'icon' => 'bx-ruler',
            ),
            5 => 
            array (
              'active' => 'admin/uom/*',
              'path' => 'admin/uom/list/1',
              'permission' => 'uom-view',
              'name' => 
              array (
                'en' => 'Unit of Measure',
                'km' => 'ខ្នាត',
              ),
              'icon' => 'bx-ruler',
            ),
            6 => 
            array (
              'active' => 'admin/setting/invoice*',
              'path' => 'admin/setting/invoice',
              'name' => 
              array (
                'en' => 'Invoice Setting',
                'km' => 'ការកំណត់វិក្កយបត្រ',
              ),
              'icon' => 'bx-receipt',
            ),
          ),
        ),
      ),
    ),
  ),
  'messaging' => 
  array (
    'url' => 'https://fcm.googleapis.com/fcm/send',
    'authorization' => NULL,
    'content_type' => 'application/json',
    'option' => 
    array (
      'content_available' => true,
      'priority' => 'high',
      'badge' => 0,
      'show_in_foreground' => true,
    ),
    'topic' => 'tcr',
  ),
  'migrator' => 
  array (
    'route' => 'migrator',
    'middleware' => 
    array (
      0 => 'AdminGuard',
    ),
    'local' => true,
    'per_page' => 50,
  ),
  'passport' => 
  array (
    'private_key' => NULL,
    'public_key' => NULL,
    'client_uuids' => false,
    'personal_access_client' => 
    array (
      'id' => NULL,
      'secret' => NULL,
    ),
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
      ),
    ),
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'teams' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => false,
    'cache' => 
    array (
      'expiration_time' => 
      \DateInterval::__set_state(array(
         'from_string' => true,
         'date_string' => '24 hours',
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'position' => 
  array (
    'type' => 
    array (
      'header' => 'Header',
      'list_product' => 'List Product',
      'list_store' => 'List Store',
      'related_product' => 'Related Product',
      'left' => 'Left',
      'right' => 'Right',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'localhost',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/Users/longdy/Documents/Projects/Laravel/POSSystem/resources/website/views',
    ),
    'compiled' => '/Users/longdy/Documents/Projects/Laravel/POSSystem/storage/framework/views',
  ),
  'website' => 
  array (
    'sort' => 
    array (
      1 => '12',
      2 => '16',
      3 => '20',
      4 => '24',
      5 => '28',
      6 => '32',
      7 => '36',
      8 => '40',
      9 => '60',
    ),
    'types' => 
    array (
      1 => 
      array (
        'type' => 'job',
        'route' => 'job',
        'icon' => 'work',
        'name' => 
        array (
          'en' => 'Jobs',
          'km' => 'ការងារ',
        ),
        'description' => 
        array (
          'en' => 'Find the best jobs you interested in',
          'km' => 'ស្វែងរកការងារដែលអ្នកចាប់អារម្មណ៍',
        ),
      ),
      2 => 
      array (
        'type' => 'hotel',
        'route' => 'hotel',
        'icon' => 'bed',
        'name' => 
        array (
          'en' => 'Hotels',
          'km' => 'សណ្ឋាគារ',
        ),
        'description' => 
        array (
          'en' => 'Find the best hotels you like',
          'km' => 'ស្វែងរកសណ្ឋាគារដែលអ្នកចូលចិត្ត',
        ),
      ),
      3 => 
      array (
        'type' => 'real-estate',
        'route' => 'real-estate',
        'icon' => 'real_estate_agent',
        'name' => 
        array (
          'en' => 'Real Estates',
          'km' => 'អចលនទ្រព្យ',
        ),
        'description' => 
        array (
          'en' => 'Find the best real estates you like',
          'km' => 'ស្វែងរកអចលនទ្រព្យដែលអ្នកចូរចិត្ត',
        ),
      ),
      4 => 
      array (
        'type' => 'product',
        'route' => 'product',
        'icon' => 'production_quantity_limits',
        'name' => 
        array (
          'en' => 'General Products',
          'km' => 'ផលិតផលទូទៅ',
        ),
        'description' => 
        array (
          'en' => 'Buy the best products you like',
          'km' => 'ទិញផលិតផលដែលអ្នកចូរចិត្ត',
        ),
      ),
    ),
    'hotel-min-price' => 
    array (
      1 => '50',
      2 => '100',
      3 => '150',
      4 => '200',
      5 => '250',
    ),
    'hotel-max-price' => 
    array (
      1 => '300',
      2 => '400',
      3 => '500',
      4 => '600',
      5 => '700',
    ),
    'real-estate-min-price' => 
    array (
      1 => '100',
      2 => '500',
      3 => '1000',
      4 => '2000',
      5 => '4000',
    ),
    'real-estate-max-price' => 
    array (
      1 => '5000',
      2 => '10000',
      3 => '15000',
      4 => '30000',
      5 => '50000',
    ),
  ),
);
