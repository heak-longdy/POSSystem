<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UbahPKBjK4iJ1UMZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q6WIpbLDRu7a33mM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4PTvorzhXX5Bd9vE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/migrator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'migrator.read',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/authorize' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.authorize',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.approve',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.deny',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/clients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/scopes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.scopes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/personal-access-tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/home-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BswYUSm7TaCKhpxf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::583TRDAK9y8vxbBE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vw3NK6zQRZeRTarR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UR6R2MkbgZZb9f8m',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WscJf1B4vys8MnUN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qIbax1OlF3RUwVyy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/check-phone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8QeWj9Jn3xh6etvj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forget-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IRKWos6Riyz05cr6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/home-page-test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::irT8dlHl65yzKxmv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/getJob' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7dvmcTKsEAP0n7c1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tqOVXSzxCT8eVNCu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/update-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hLvrkzQrxteA0Sej',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qjoQa0u71pxXL56G',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/delete-account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jPg7XOjyPav6FOzZ',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/wallet' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CSWrd7a4Ggw6ovkC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/store-wallet' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sgSQPmLnvbx4HhZj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GIOh1WIJv2H5TvwK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/store-customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::27RZZhVTTKKtrGRG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/earning' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e3BQiiQIRc7aHP1m',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZwKwyV3vrjHHlK7J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/store-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qeSIOpKoMVzEXZEB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L1rJl55ViJr9VsPa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8nnrvDsSxFbF6OBt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/search-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8WmTUBnXc2asVMRT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/search-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RjvEteMuWrFZTpSL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/barber-commission' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KGgOdAdgS0reEOMf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/payment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mMvYMFabuUe9EbL1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pending' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TkXvxA4U0zMwQaba',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/paid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DLT66VfOZevayJ1Z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reward' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a54NpmMrf6EhOKNE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GnXKQHD9VtDw1zSo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/verifyDoc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-verifyDoc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/internship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-job',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-blog',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-contact',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/contact/send' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-contact-send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/our-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-our-service',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/userIndex' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-userIndex',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/userData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-user-data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/apply' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-apply',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/select/position' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-select-position',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/select/sector' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-select-sector',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/hhhh/select/internship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-select-job',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/setting/invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-setting-invoice-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/setting/invoice/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-setting-invoice-save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/auth/forgot' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-forgot-password',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/auth/login/post' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-login-post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/auth/sign-out' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sign-out',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/product/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/shop/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/shop/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/category/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/supplier/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/partner/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/partner/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/sector/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/sector/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/position/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/position/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/staff/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/staff/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/user/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/internships/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/internships/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/blog/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/blog/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/placement-type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/placement-type/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/testimonial/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/testimonial/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/customer/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/customer-paid/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/customer-paid/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/OurService' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-our-service-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/OurService/Save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-our-service-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/aboutUs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-about-us-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/aboutUs/Save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-about-us-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stock-in/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stock-out/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stock-transfer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stock-on-hand/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-on-hand-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stock-movement/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-movement-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/uom/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/uom/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-product-by-shop',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-customer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-supplier',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/stock-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-stock-product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/stock-shop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-stock-shop',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/shopNotIn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-shopNotIn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/shop-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-shop-product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/find-shop-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-find-shop-product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/barber' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-barber',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/shop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-shop',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/type-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/type-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-service',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/shop-in-product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-shop-in-product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/position' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-position',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/sector' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-sector',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-category',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/uom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-uom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/select/placement-type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-select-placement-type',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/order/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/order/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/remaining-amount/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/remaining-amount/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/setting/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-setting-setting',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/setting/invoice/preview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-setting-invoice-preview',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/index' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/first' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-first',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/files' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-files',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/folders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-folders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/rename-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-rename-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/delete-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-delete-file',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/create-folder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-create-folder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/rename-folder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-rename-folder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/delete-folder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-delete-folder',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/delete-all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-delete-all',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/file-manager/restore-all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-file-manager-restore-all',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/staff-expense/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/staff-expense/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-sales-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/sales/daily' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-sales-daily',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/sales/monthly' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-sales-monthly',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/sales/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-sales-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/order-transaction' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-order-transaction-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/order-transaction/daily' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-order-transaction-daily',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/order-transaction/monthly' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-order-transaction-monthly',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/order-transaction/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-order-transaction-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/inventory-movement' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-inventory-movement-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/inventory-movement/daily' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-inventory-movement-daily',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/inventory-movement/monthly' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-inventory-movement-monthly',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/inventory-movement/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-inventory-movement-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/customer-remaining-amount' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-customer-remaining-amount-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/staff-expense' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-staff-expense-index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/staff-expense/daily' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-staff-expense-daily',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/staff-expense/monthly' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-staff-expense-monthly',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report/staff-expense/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-staff-expense-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/clear-cache-s' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-clear-cache-s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/clear-cache' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-clear-cache',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/livewire/message/([^/]++)(*:33)|/([^/]++)/livewire/message/([^/]++)(*:75)|/livewire/preview\\-file/([^/]++)(*:114)|/oauth/(?|tokens/([^/]++)(*:147)|clients/([^/]++)(?|(*:174))|personal\\-access\\-tokens/([^/]++)(*:216))|/a(?|pi/detail/([^/]++)(*:248)|dmin/(?|p(?|roduct/(?|list(?:/([^/]++))?(*:296)|edit(?:/([^/]++))?(*:322)|s(?|ave(?|(?:/([^/]++))?(*:354)|\\-p(?|assword(?:/([^/]++))?(*:389)|ermission(?:/([^/]++))?(*:420)))|tatus/([^/]++)/([^/]++)(*:453))|de(?|lete(?:/([^/]++))?(*:485)|stroy(?:/([^/]++))?(*:512))|restore(?:/([^/]++))?(*:542)|change\\-password(?:/([^/]++))?(*:580)|permission(?:/([^/]++))?(*:612))|a(?|rtner/(?|list(?:/([^/]++))?(*:652)|edit(?:/([^/]++))?(*:678)|s(?|ave(?|(?:/([^/]++))?(*:710)|\\-p(?|assword(?:/([^/]++))?(*:745)|ermission(?:/([^/]++))?(*:776)))|tatus/([^/]++)/([^/]++)(*:809))|de(?|lete(?:/([^/]++))?(*:841)|stroy(?:/([^/]++))?(*:868))|restore(?:/([^/]++))?(*:898)|change\\-password(?:/([^/]++))?(*:936)|permission(?:/([^/]++))?(*:968))|ge(?|(?:/([^/]++))?(*:996)|/save(?:/([^/]++))?(*:1023)))|osition/(?|list(?:/([^/]++))?(*:1063)|edit(?:/([^/]++))?(*:1090)|s(?|ave(?|(?:/([^/]++))?(*:1123)|\\-p(?|assword(?:/([^/]++))?(*:1159)|ermission(?:/([^/]++))?(*:1191)))|tatus/([^/]++)/([^/]++)(*:1225))|de(?|lete(?:/([^/]++))?(*:1258)|stroy(?:/([^/]++))?(*:1286))|restore(?:/([^/]++))?(*:1317)|change\\-password(?:/([^/]++))?(*:1356)|permission(?:/([^/]++))?(*:1389))|lacement\\-type/(?|list(?:/([^/]++))?(*:1435)|edit(?:/([^/]++))?(*:1462)|s(?|ave(?|(?:/([^/]++))?(*:1495)|\\-p(?|assword(?:/([^/]++))?(*:1531)|ermission(?:/([^/]++))?(*:1563)))|tatus/([^/]++)/([^/]++)(*:1597))|de(?|lete(?:/([^/]++))?(*:1630)|stroy(?:/([^/]++))?(*:1658))|restore(?:/([^/]++))?(*:1689)|change\\-password(?:/([^/]++))?(*:1728)|permission(?:/([^/]++))?(*:1761)))|s(?|hop/(?|list(?:/([^/]++))?(*:1801)|edit(?:/([^/]++))?(*:1828)|s(?|ave(?|(?:/([^/]++))?(*:1861)|\\-p(?|assword(?:/([^/]++))?(*:1897)|ermission(?:/([^/]++))?(*:1929)))|tatus/([^/]++)/([^/]++)(*:1963))|de(?|lete(?:/([^/]++))?(*:1996)|stroy(?:/([^/]++))?(*:2024))|restore(?:/([^/]++))?(*:2055)|change\\-password(?:/([^/]++))?(*:2094)|p(?|ermission(?:/([^/]++))?(*:2130)|roduct/(?|([^/]++)(?|/(?|create(*:2170)|edit/([^/]++)(*:2192)|de(?|lete/([^/]++)(*:2219)|stroy/([^/]++)(*:2242))|restore/([^/]++)(*:2268))|(*:2278))|save/([^/]++)(*:2301))))|upplier/(?|list(?:/([^/]++))?(*:2342)|edit(?:/([^/]++))?(*:2369)|s(?|ave(?|(?:/([^/]++))?(*:2402)|\\-p(?|assword(?:/([^/]++))?(*:2438)|ermission(?:/([^/]++))?(*:2470)))|tatus/([^/]++)/([^/]++)(*:2504))|de(?|lete(?:/([^/]++))?(*:2537)|stroy(?:/([^/]++))?(*:2565))|restore(?:/([^/]++))?(*:2596)|change\\-password(?:/([^/]++))?(*:2635)|permission(?:/([^/]++))?(*:2668))|e(?|ctor/(?|list(?:/([^/]++))?(*:2708)|edit(?:/([^/]++))?(*:2735)|s(?|ave(?|(?:/([^/]++))?(*:2768)|\\-p(?|assword(?:/([^/]++))?(*:2804)|ermission(?:/([^/]++))?(*:2836)))|tatus/([^/]++)/([^/]++)(*:2870))|de(?|lete(?:/([^/]++))?(*:2903)|stroy(?:/([^/]++))?(*:2931))|restore(?:/([^/]++))?(*:2962)|change\\-password(?:/([^/]++))?(*:3001)|permission(?:/([^/]++))?(*:3034))|tting/save(?:/([^/]++))?(*:3068))|t(?|aff(?|/(?|list(?:/([^/]++))?(*:3110)|edit(?:/([^/]++))?(*:3137)|s(?|ave(?|(?:/([^/]++))?(*:3170)|\\-p(?|assword(?:/([^/]++))?(*:3206)|ermission(?:/([^/]++))?(*:3238)))|tatus/([^/]++)/([^/]++)(*:3272))|de(?|lete(?:/([^/]++))?(*:3305)|stroy(?:/([^/]++))?(*:3333))|restore(?:/([^/]++))?(*:3364)|change\\-password(?:/([^/]++))?(*:3403)|permission(?:/([^/]++))?(*:3436))|\\-expense/(?|list(?:/([^/]++))?(*:3477)|edit(?:/([^/]++))?(*:3504)|s(?|ave(?|(?:/([^/]++))?(*:3537)|\\-p(?|assword(?:/([^/]++))?(*:3573)|ermission(?:/([^/]++))?(*:3605)))|ta(?|tus/([^/]++)/([^/]++)(*:3642)|ff/([^/]++)(*:3662)))|de(?|lete(?:/([^/]++))?(*:3696)|stroy(?:/([^/]++))?(*:3724))|restore(?:/([^/]++))?(*:3755)|change\\-password(?:/([^/]++))?(*:3794)|permission(?:/([^/]++))?(*:3827)))|ock\\-(?|in/(?|list(?:/([^/]++))?(*:3870)|edit(?:/([^/]++))?(*:3897)|view(?:/([^/]++))?(*:3924)|s(?|ave(?:/([^/]++))?(*:3954)|tatus/([^/]++)/([^/]++)(*:3986))|products/([^/]++)(*:4013)|de(?|lete(?:/([^/]++))?(*:4045)|stroy(?:/([^/]++))?(*:4073))|restore(?:/([^/]++))?(*:4104))|o(?|ut/(?|list(?:/([^/]++))?(*:4142)|edit(?:/([^/]++))?(*:4169)|view(?:/([^/]++))?(*:4196)|s(?|ave(?:/([^/]++))?(*:4226)|tatus/([^/]++)/([^/]++)(*:4258))|de(?|lete(?:/([^/]++))?(*:4291)|stroy(?:/([^/]++))?(*:4319))|restore(?:/([^/]++))?(*:4350))|n\\-hand/(?|list(?:/([^/]++))?(*:4389)|view(?:/([^/]++))?(*:4416)|find(?:/([^/]++)(?:/([^/]++))?)?(*:4457)))|transfer/(?|list(?:/([^/]++))?(*:4498)|edit(?:/([^/]++))?(*:4525)|view(?:/([^/]++))?(*:4552)|s(?|ave(?:/([^/]++))?(*:4582)|tatus/([^/]++)/([^/]++)(*:4614))|update(?:/([^/]++))?(*:4644)|de(?|lete(?:/([^/]++))?(*:4676)|stroy(?:/([^/]++))?(*:4704))|restore(?:/([^/]++))?(*:4735))|movement/(?|list(?:/([^/]++))?(*:4775)|view(?:/([^/]++))?(*:4802)))))|c(?|ategory/(?|list(?:/([^/]++))?(*:4848)|edit(?:/([^/]++))?(*:4875)|s(?|ave(?|(?:/([^/]++))?(*:4908)|\\-p(?|assword(?:/([^/]++))?(*:4944)|ermission(?:/([^/]++))?(*:4976)))|tatus/([^/]++)/([^/]++)(*:5010))|de(?|lete(?:/([^/]++))?(*:5043)|stroy(?:/([^/]++))?(*:5071))|restore(?:/([^/]++))?(*:5102)|change\\-password(?:/([^/]++))?(*:5141)|permission(?:/([^/]++))?(*:5174))|ustomer(?|/(?|list(?:/([^/]++))?(*:5216)|edit(?:/([^/]++))?(*:5243)|s(?|ave(?|(?:/([^/]++))?(*:5276)|\\-p(?|assword(?:/([^/]++))?(*:5312)|ermission(?:/([^/]++))?(*:5344)))|tatus/([^/]++)/([^/]++)(*:5378))|de(?|lete(?:/([^/]++))?(*:5411)|stroy(?:/([^/]++))?(*:5439))|restore(?:/([^/]++))?(*:5470)|change\\-password(?:/([^/]++))?(*:5509)|permission(?:/([^/]++))?(*:5542))|\\-paid/(?|list(?:/([^/]++))?(*:5580)|edit(?:/([^/]++))?(*:5607)|s(?|ave(?|(?:/([^/]++))?(*:5640)|\\-p(?|assword(?:/([^/]++))?(*:5676)|ermission(?:/([^/]++))?(*:5708)))|tatus/([^/]++)/([^/]++)(*:5742))|de(?|lete(?:/([^/]++))?(*:5775)|stroy(?:/([^/]++))?(*:5803))|restore(?:/([^/]++))?(*:5834)|change\\-password(?:/([^/]++))?(*:5873)|permission(?:/([^/]++))?(*:5906)))|ontact(?|(?:/([^/]++))?(*:5940)|/save(?:/([^/]++))?(*:5968)))|u(?|ser/(?|list(?:/([^/]++))?(*:6008)|edit(?:/([^/]++))?(*:6035)|s(?|ave(?|(?:/([^/]++))?(*:6068)|\\-p(?|assword(?:/([^/]++))?(*:6104)|ermission(?:/([^/]++))?(*:6136)))|tatus/([^/]++)/([^/]++)(*:6170))|de(?|lete(?:/([^/]++))?(*:6203)|stroy(?:/([^/]++))?(*:6231))|restore(?:/([^/]++))?(*:6262)|change\\-password(?:/([^/]++))?(*:6301)|permission(?:/([^/]++))?(*:6334))|om/(?|list(?:/([^/]++))?(*:6368)|edit(?:/([^/]++))?(*:6395)|s(?|ave(?|(?:/([^/]++))?(*:6428)|\\-p(?|assword(?:/([^/]++))?(*:6464)|ermission(?:/([^/]++))?(*:6496)))|tatus/([^/]++)/([^/]++)(*:6530))|de(?|lete(?:/([^/]++))?(*:6563)|stroy(?:/([^/]++))?(*:6591))|restore(?:/([^/]++))?(*:6622)|change\\-password(?:/([^/]++))?(*:6661)|permission(?:/([^/]++))?(*:6694)))|internships/(?|list(?:/([^/]++))?(*:6738)|edit(?:/([^/]++))?(*:6765)|s(?|ave(?|(?:/([^/]++))?(*:6798)|\\-p(?|assword(?:/([^/]++))?(*:6834)|ermission(?:/([^/]++))?(*:6866)))|tatus/([^/]++)/([^/]++)(*:6900))|de(?|lete(?:/([^/]++))?(*:6933)|stroy(?:/([^/]++))?(*:6961))|restore(?:/([^/]++))?(*:6992)|change\\-password(?:/([^/]++))?(*:7031)|permission(?:/([^/]++))?(*:7064))|blog/(?|list(?:/([^/]++))?(*:7100)|edit(?:/([^/]++))?(*:7127)|s(?|ave(?|(?:/([^/]++))?(*:7160)|\\-p(?|assword(?:/([^/]++))?(*:7196)|ermission(?:/([^/]++))?(*:7228)))|tatus/([^/]++)/([^/]++)(*:7262))|de(?|lete(?:/([^/]++))?(*:7295)|stroy(?:/([^/]++))?(*:7323))|restore(?:/([^/]++))?(*:7354)|change\\-password(?:/([^/]++))?(*:7393)|permission(?:/([^/]++))?(*:7426))|testimonial/(?|list(?:/([^/]++))?(*:7469)|edit(?:/([^/]++))?(*:7496)|s(?|ave(?|(?:/([^/]++))?(*:7529)|\\-p(?|assword(?:/([^/]++))?(*:7565)|ermission(?:/([^/]++))?(*:7597)))|tatus/([^/]++)/([^/]++)(*:7631))|de(?|lete(?:/([^/]++))?(*:7664)|stroy(?:/([^/]++))?(*:7692))|restore(?:/([^/]++))?(*:7723)|change\\-password(?:/([^/]++))?(*:7762)|permission(?:/([^/]++))?(*:7795))|order/(?|list(?|(?:/([^/]++))?(*:7835)|\\-product(?:/([^/]++))?(*:7867))|s(?|tatus/([^/]++)/([^/]++)(*:7904)|ave(?:/([^/]++))?(*:7930)|end\\-payment\\-reminder/([^/]++)(*:7970))|edit(?:/([^/]++))?(*:7998)|de(?|tail/([^/]++)(*:8025)|lete(?|/([^/]++)(*:8050)|\\-payment/([^/]++)(*:8077))|stroy/([^/]++)(*:8101))|restore/([^/]++)(*:8127)|payment\\-details/([^/]++)(*:8161)|add\\-payment/([^/]++)(*:8191)|update\\-payment(?|/([^/]++)(*:8227)|\\-status/([^/]++)(*:8253))|cancel/([^/]++)(*:8278))|re(?|maining\\-amount/(?|list(?:/([^/]++))?(*:8330)|de(?|tail/([^/]++)(*:8357)|lete\\-payment/([^/]++)(*:8388))|payment\\-details/([^/]++)(*:8423)|add\\-payment/([^/]++)(*:8453)|update\\-payment/([^/]++)(*:8486)|send\\-reminder/([^/]++)(*:8518))|port/(?|s(?|ales/details/([^/]++)(*:8561)|taff\\-expense/details/([^/]++)(*:8600))|order\\-transaction/details/([^/]++)(*:8645)|inventory\\-movement/details/([^/]++)(*:8690)|customer\\-remaining\\-amount/details/([0-9]+)(*:8743)))))|/hhhh/(?|internship/detail/([^/]++)(*:8791)|blog/detail/([^/]++)(*:8820)|apply/form(?:/([^/]++))?(*:8853)))/?$}sDu',
    ),
    3 => 
    array (
      33 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message-localized',
          ),
          1 => 
          array (
            0 => 'locale',
            1 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.update',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.destroy',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      216 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j2tcO5XXnFUsSHlA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      322 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      420 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      485 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      512 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      542 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-product-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      652 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      678 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      745 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      776 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      841 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      936 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      968 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-partner-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-page-page',
            'type' => NULL,
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1023 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-page-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1191 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1286 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1317 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1356 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-position-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1435 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1495 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1531 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1658 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1761 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-placement-type-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1801 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1828 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1861 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1929 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1963 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2024 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2055 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2094 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-create',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-edit',
          ),
          1 => 
          array (
            0 => 'shopId',
            1 => 'shopProductId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-delete',
          ),
          1 => 
          array (
            0 => 'shopId',
            1 => 'shopProductId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-destroy',
          ),
          1 => 
          array (
            0 => 'shopId',
            1 => 'shopProductId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2268 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-restore',
          ),
          1 => 
          array (
            0 => 'shopId',
            1 => 'shopProductId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-shop-product-save',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2342 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2369 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2402 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2438 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2470 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2635 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-supplier-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2735 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2836 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2903 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2931 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2962 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3001 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3034 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-sector-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3068 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-setting-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3110 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3137 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3272 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3305 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3364 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3403 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3573 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3605 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3642 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3662 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-staff-history',
          ),
          1 => 
          array (
            0 => 'staffId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3696 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3724 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3755 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3794 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3827 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-staff-expense-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3924 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3954 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3986 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4013 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-products',
          ),
          1 => 
          array (
            0 => 'shop_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4045 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4073 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-in-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4169 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4226 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-out-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-on-hand-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4416 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-on-hand-view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4457 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-on-hand-onFind',
            'product_id' => NULL,
            'shop_id' => NULL,
          ),
          1 => 
          array (
            0 => 'product_id',
            1 => 'shop_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4498 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4525 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4552 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4644 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4704 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4735 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-transfer-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-movement-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-stock-movement-view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4875 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4908 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4976 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5010 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5043 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5071 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-category-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5216 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5243 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5312 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5344 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5378 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5411 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5439 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5470 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5509 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5542 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5607 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5803 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5834 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5873 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5906 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-customer-paid-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5940 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-contact-contact',
            'type' => NULL,
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5968 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-contact-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6035 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6068 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6136 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6231 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6262 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6334 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-user-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6368 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6428 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6464 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6622 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6694 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-uom-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6738 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6834 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6900 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6933 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      6992 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7031 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7064 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-internships-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7100 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7160 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7228 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7262 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7295 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7323 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7393 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-blog-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7469 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-save-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7597 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-save-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7631 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7692 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-destroy',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7723 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-restore',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-change-password',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7795 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-testimonial-permission',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7835 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-list-product',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-status',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7930 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-save',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-send-payment-reminder',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      7998 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8025 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8050 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8077 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-delete-payment',
          ),
          1 => 
          array (
            0 => 'paymentId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8161 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-payment-details',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8191 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-add-payment',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8227 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-update-payment',
          ),
          1 => 
          array (
            0 => 'paymentId',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8253 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-update-payment-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-order-cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-list',
            'status' => NULL,
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8357 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-delete-payment',
          ),
          1 => 
          array (
            0 => 'paymentId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8423 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-payment-details',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-add-payment',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8486 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-update-payment',
          ),
          1 => 
          array (
            0 => 'paymentId',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8518 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-remaining-amount-send-reminder',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8561 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-sales-details',
          ),
          1 => 
          array (
            0 => 'period',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-staff-expense-details',
          ),
          1 => 
          array (
            0 => 'period',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8645 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-order-transaction-details',
          ),
          1 => 
          array (
            0 => 'period',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8690 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-inventory-movement-details',
          ),
          1 => 
          array (
            0 => 'period',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-report-customer-remaining-amount-details',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-job-detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8820 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-blog-detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      8853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'web-apply-form',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::UbahPKBjK4iJ1UMZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::UbahPKBjK4iJ1UMZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message-localized' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{locale}/livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message-localized',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'controller' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'as' => 'livewire.upload-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'controller' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'as' => 'livewire.preview-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q6WIpbLDRu7a33mM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'as' => 'generated::q6WIpbLDRu7a33mM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4PTvorzhXX5Bd9vE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'as' => 'generated::4PTvorzhXX5Bd9vE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'migrator.read' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'migrator',
      'action' => 
      array (
        'uses' => 'Migrator\\Http\\Livewire\\Migration\\Read@__invoke',
        'controller' => 'Migrator\\Http\\Livewire\\Migration\\Read',
        'as' => 'migrator.read',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AdminGuard',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.authorize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'as' => 'passport.authorizations.authorize',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'as' => 'passport.authorizations.approve',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.authorizations.deny' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'as' => 'passport.authorizations.deny',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.token' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token',
      'action' => 
      array (
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'as' => 'passport.token',
        'middleware' => 'throttle',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'as' => 'passport.tokens.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'as' => 'passport.tokens.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.token.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'as' => 'passport.token.refresh',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'as' => 'passport.clients.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'as' => 'passport.clients.store',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'as' => 'passport.clients.update',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.clients.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'as' => 'passport.clients.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.scopes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/scopes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'as' => 'passport.scopes.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'as' => 'passport.personal.tokens.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'as' => 'passport.personal.tokens.store',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'passport.personal.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/personal-access-tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'as' => 'passport.personal.tokens.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BswYUSm7TaCKhpxf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/home-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::BswYUSm7TaCKhpxf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::583TRDAK9y8vxbBE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PageController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PageController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::583TRDAK9y8vxbBE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vw3NK6zQRZeRTarR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PageController@contact',
        'controller' => 'App\\Http\\Controllers\\Api\\PageController@contact',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vw3NK6zQRZeRTarR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UR6R2MkbgZZb9f8m' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CountryController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CountryController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::UR6R2MkbgZZb9f8m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WscJf1B4vys8MnUN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::WscJf1B4vys8MnUN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qIbax1OlF3RUwVyy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qIbax1OlF3RUwVyy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8QeWj9Jn3xh6etvj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/check-phone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@checkPhone',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@checkPhone',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8QeWj9Jn3xh6etvj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IRKWos6Riyz05cr6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forget-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@forgetPassword',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@forgetPassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IRKWos6Riyz05cr6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::irT8dlHl65yzKxmv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/home-page-test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@index2',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@index2',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::irT8dlHl65yzKxmv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7dvmcTKsEAP0n7c1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/getJob',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@getJob',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@getJob',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7dvmcTKsEAP0n7c1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tqOVXSzxCT8eVNCu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@profile',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@profile',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::tqOVXSzxCT8eVNCu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hLvrkzQrxteA0Sej' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/update-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@updateProfile',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::hLvrkzQrxteA0Sej',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qjoQa0u71pxXL56G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@changePassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qjoQa0u71pxXL56G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jPg7XOjyPav6FOzZ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/delete-account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@deleteAccount',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@deleteAccount',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jPg7XOjyPav6FOzZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CSWrd7a4Ggw6ovkC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/wallet',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\WalletController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\WalletController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CSWrd7a4Ggw6ovkC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sgSQPmLnvbx4HhZj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store-wallet',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\WalletController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\WalletController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sgSQPmLnvbx4HhZj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GIOh1WIJv2H5TvwK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomerController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::GIOh1WIJv2H5TvwK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::27RZZhVTTKKtrGRG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store-customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CustomerController@onSave',
        'controller' => 'App\\Http\\Controllers\\Api\\CustomerController@onSave',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::27RZZhVTTKKtrGRG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e3BQiiQIRc7aHP1m' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/earning',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::e3BQiiQIRc7aHP1m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZwKwyV3vrjHHlK7J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZwKwyV3vrjHHlK7J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qeSIOpKoMVzEXZEB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qeSIOpKoMVzEXZEB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L1rJl55ViJr9VsPa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@service',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@service',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::L1rJl55ViJr9VsPa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8nnrvDsSxFbF6OBt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@product',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@product',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8nnrvDsSxFbF6OBt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8WmTUBnXc2asVMRT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/search-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@searchProduct',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@searchProduct',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8WmTUBnXc2asVMRT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RjvEteMuWrFZTpSL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/search-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HomeController@searchService',
        'controller' => 'App\\Http\\Controllers\\Api\\HomeController@searchService',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::RjvEteMuWrFZTpSL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KGgOdAdgS0reEOMf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/barber-commission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CommissionController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::KGgOdAdgS0reEOMf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j2tcO5XXnFUsSHlA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@detail',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@detail',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::j2tcO5XXnFUsSHlA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mMvYMFabuUe9EbL1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@payment',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@payment',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mMvYMFabuUe9EbL1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TkXvxA4U0zMwQaba' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pending',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@pending',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@pending',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::TkXvxA4U0zMwQaba',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DLT66VfOZevayJ1Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/paid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\BookingController@paid',
        'controller' => 'App\\Http\\Controllers\\Api\\BookingController@paid',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::DLT66VfOZevayJ1Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a54NpmMrf6EhOKNE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reward',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RewardController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RewardController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::a54NpmMrf6EhOKNE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GnXKQHD9VtDw1zSo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:barber-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RewardController@reward',
        'controller' => 'App\\Http\\Controllers\\Api\\RewardController@reward',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::GnXKQHD9VtDw1zSo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-verifyDoc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/verifyDoc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\HomeController@verifyDoc',
        'controller' => 'App\\Http\\Controllers\\website\\HomeController@verifyDoc',
        'as' => 'web-verifyDoc',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\website\\HomeController@index',
        'as' => 'web-index',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-job' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/internship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\JobController@job',
        'controller' => 'App\\Http\\Controllers\\website\\JobController@job',
        'as' => 'web-job',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-job-detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/internship/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\JobController@jobDetail',
        'controller' => 'App\\Http\\Controllers\\website\\JobController@jobDetail',
        'as' => 'web-job-detail',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-blog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\BlogController@blog',
        'controller' => 'App\\Http\\Controllers\\website\\BlogController@blog',
        'as' => 'web-blog',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-blog-detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/blog/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\BlogController@blogDetail',
        'controller' => 'App\\Http\\Controllers\\website\\BlogController@blogDetail',
        'as' => 'web-blog-detail',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-contact' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\ContactController@contact',
        'controller' => 'App\\Http\\Controllers\\website\\ContactController@contact',
        'as' => 'web-contact',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-contact-send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hhhh/contact/send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\ContactController@contactSend',
        'controller' => 'App\\Http\\Controllers\\website\\ContactController@contactSend',
        'as' => 'web-contact-send',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-our-service' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/our-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\OurServiceController@ourService',
        'controller' => 'App\\Http\\Controllers\\website\\OurServiceController@ourService',
        'as' => 'web-our-service',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\AboutController@about',
        'controller' => 'App\\Http\\Controllers\\website\\AboutController@about',
        'as' => 'web-about',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hhhh/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\HomeController@upload',
        'controller' => 'App\\Http\\Controllers\\website\\HomeController@upload',
        'as' => 'web-upload',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-userIndex' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/userIndex',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\HomeController@userIndex',
        'controller' => 'App\\Http\\Controllers\\website\\HomeController@userIndex',
        'as' => 'web-userIndex',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-user-data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/userData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\HomeController@userData',
        'controller' => 'App\\Http\\Controllers\\website\\HomeController@userData',
        'as' => 'web-user-data',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-apply-form' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/apply/form/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\ApplyFormController@applyForm',
        'controller' => 'App\\Http\\Controllers\\website\\ApplyFormController@applyForm',
        'as' => 'web-apply-form',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-apply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'hhhh/apply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\ApplyFormController@apply',
        'controller' => 'App\\Http\\Controllers\\website\\ApplyFormController@apply',
        'as' => 'web-apply',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-select-position' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/select/position',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\SelectController@SelectPositionSearch',
        'controller' => 'App\\Http\\Controllers\\website\\SelectController@SelectPositionSearch',
        'as' => 'web-select-position',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-select-sector' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/select/sector',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\SelectController@SelectSectorSearch',
        'controller' => 'App\\Http\\Controllers\\website\\SelectController@SelectSectorSearch',
        'as' => 'web-select-sector',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'web-select-job' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'hhhh/select/internship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\website\\SelectController@SelectJobSearch',
        'controller' => 'App\\Http\\Controllers\\website\\SelectController@SelectJobSearch',
        'as' => 'web-select-job',
        'namespace' => NULL,
        'prefix' => '/hhhh',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-setting-invoice-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/setting/invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@index',
        'as' => 'admin-setting-invoice-index',
        'namespace' => NULL,
        'prefix' => 'admin/setting',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-setting-invoice-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/setting/invoice/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@save',
        'controller' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@save',
        'as' => 'admin-setting-invoice-save',
        'namespace' => NULL,
        'prefix' => 'admin/setting',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@login',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@login',
        'as' => 'admin-login',
        'namespace' => NULL,
        'prefix' => 'admin/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-forgot-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/auth/forgot',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@forgotPassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@forgotPassword',
        'as' => 'admin-forgot-password',
        'namespace' => NULL,
        'prefix' => 'admin/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-login-post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/auth/login/post',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuthController@login',
        'as' => 'admin-login-post',
        'namespace' => NULL,
        'prefix' => 'admin/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sign-out' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/auth/sign-out',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuthController@signOut',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuthController@signOut',
        'as' => 'admin-sign-out',
        'namespace' => NULL,
        'prefix' => 'admin/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:299:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:81:"function () {
            return \\redirect()->route(\'admin-dashboard\');
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006e80000000000000000";}";s:4:"hash";s:44:"Owz5gVhV9OD5QHgMPz4zVk7WcbuzS/Cd4h+HIKzHei4=";}}',
        'as' => 'admin-home',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'as' => 'admin-dashboard',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@index',
        'as' => 'admin-product-list',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onCreate',
        'as' => 'admin-product-create',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onEdit',
        'as' => 'admin-product-edit',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@Save',
        'as' => 'admin-product-save',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/product/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@updateStatus',
        'as' => 'admin-product-status',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@delete',
        'as' => 'admin-product-delete',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@restore',
        'as' => 'admin-product-restore',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@destroy',
        'as' => 'admin-product-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onChangePassword',
        'as' => 'admin-product-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onSavePassword',
        'as' => 'admin-product-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onPermission',
        'as' => 'admin-product-permission',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/product/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@onSavePermission',
        'as' => 'admin-product-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-product-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@export',
        'as' => 'admin-product-export',
        'namespace' => NULL,
        'prefix' => 'admin/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@index',
        'as' => 'admin-shop-list',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onCreate',
        'as' => 'admin-shop-create',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onEdit',
        'as' => 'admin-shop-edit',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@Save',
        'as' => 'admin-shop-save',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/shop/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@updateStatus',
        'as' => 'admin-shop-status',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@delete',
        'as' => 'admin-shop-delete',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@restore',
        'as' => 'admin-shop-restore',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@destroy',
        'as' => 'admin-shop-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onChangePassword',
        'as' => 'admin-shop-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onSavePassword',
        'as' => 'admin-shop-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onPermission',
        'as' => 'admin-shop-permission',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onSavePermission',
        'as' => 'admin-shop-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@export',
        'as' => 'admin-shop-export',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/product/{id}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onCreateProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onCreateProduct',
        'as' => 'admin-shop-product-create',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/product/{shopId}/edit/{shopProductId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onEditProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onEditProduct',
        'as' => 'admin-shop-product-edit',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/product/{shopId}/delete/{shopProductId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@deleteProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@deleteProduct',
        'as' => 'admin-shop-product-delete',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/product/{shopId}/restore/{shopProductId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@restoreProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@restoreProduct',
        'as' => 'admin-shop-product-restore',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/product/{shopId}/destroy/{shopProductId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@destroyProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@destroyProduct',
        'as' => 'admin-shop-product-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shop/product/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@onProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@onProduct',
        'as' => 'admin-shop-product',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-shop-product-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shop/product/save/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShopController@saveProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShopController@saveProduct',
        'as' => 'admin-shop-product-save',
        'namespace' => NULL,
        'prefix' => 'admin/shop',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@index',
        'as' => 'admin-category-list',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onCreate',
        'as' => 'admin-category-create',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onEdit',
        'as' => 'admin-category-edit',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@Save',
        'as' => 'admin-category-save',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/category/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@updateStatus',
        'as' => 'admin-category-status',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@delete',
        'as' => 'admin-category-delete',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@restore',
        'as' => 'admin-category-restore',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'as' => 'admin-category-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onChangePassword',
        'as' => 'admin-category-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onSavePassword',
        'as' => 'admin-category-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onPermission',
        'as' => 'admin-category-permission',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@onSavePermission',
        'as' => 'admin-category-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-category-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@export',
        'as' => 'admin-category-export',
        'namespace' => NULL,
        'prefix' => 'admin/category',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@index',
        'as' => 'admin-supplier-list',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onCreate',
        'as' => 'admin-supplier-create',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onEdit',
        'as' => 'admin-supplier-edit',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@Save',
        'as' => 'admin-supplier-save',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/supplier/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@updateStatus',
        'as' => 'admin-supplier-status',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@delete',
        'as' => 'admin-supplier-delete',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@restore',
        'as' => 'admin-supplier-restore',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@destroy',
        'as' => 'admin-supplier-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onChangePassword',
        'as' => 'admin-supplier-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onSavePassword',
        'as' => 'admin-supplier-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onPermission',
        'as' => 'admin-supplier-permission',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/supplier/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@onSavePermission',
        'as' => 'admin-supplier-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-supplier-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/supplier/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupplierController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupplierController@export',
        'as' => 'admin-supplier-export',
        'namespace' => NULL,
        'prefix' => 'admin/supplier',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@index',
        'as' => 'admin-partner-list',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onCreate',
        'as' => 'admin-partner-create',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onEdit',
        'as' => 'admin-partner-edit',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@Save',
        'as' => 'admin-partner-save',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/partner/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@updateStatus',
        'as' => 'admin-partner-status',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@delete',
        'as' => 'admin-partner-delete',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@restore',
        'as' => 'admin-partner-restore',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@destroy',
        'as' => 'admin-partner-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onChangePassword',
        'as' => 'admin-partner-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onSavePassword',
        'as' => 'admin-partner-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onPermission',
        'as' => 'admin-partner-permission',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/partner/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@onSavePermission',
        'as' => 'admin-partner-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-partner-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/partner/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PartnerController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\PartnerController@export',
        'as' => 'admin-partner-export',
        'namespace' => NULL,
        'prefix' => 'admin/partner',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@index',
        'as' => 'admin-sector-list',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onCreate',
        'as' => 'admin-sector-create',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onEdit',
        'as' => 'admin-sector-edit',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@Save',
        'as' => 'admin-sector-save',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/sector/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@updateStatus',
        'as' => 'admin-sector-status',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@delete',
        'as' => 'admin-sector-delete',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@restore',
        'as' => 'admin-sector-restore',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@destroy',
        'as' => 'admin-sector-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onChangePassword',
        'as' => 'admin-sector-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onSavePassword',
        'as' => 'admin-sector-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onPermission',
        'as' => 'admin-sector-permission',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/sector/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@onSavePermission',
        'as' => 'admin-sector-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-sector-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sector/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SectorController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\SectorController@export',
        'as' => 'admin-sector-export',
        'namespace' => NULL,
        'prefix' => 'admin/sector',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@index',
        'as' => 'admin-position-list',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onCreate',
        'as' => 'admin-position-create',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onEdit',
        'as' => 'admin-position-edit',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@Save',
        'as' => 'admin-position-save',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/position/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@updateStatus',
        'as' => 'admin-position-status',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@delete',
        'as' => 'admin-position-delete',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@restore',
        'as' => 'admin-position-restore',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@destroy',
        'as' => 'admin-position-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onChangePassword',
        'as' => 'admin-position-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onSavePassword',
        'as' => 'admin-position-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onPermission',
        'as' => 'admin-position-permission',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/position/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@onSavePermission',
        'as' => 'admin-position-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-position-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/position/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PositionController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\PositionController@export',
        'as' => 'admin-position-export',
        'namespace' => NULL,
        'prefix' => 'admin/position',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@index',
        'as' => 'admin-staff-list',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onCreate',
        'as' => 'admin-staff-create',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onEdit',
        'as' => 'admin-staff-edit',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@Save',
        'as' => 'admin-staff-save',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/staff/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@updateStatus',
        'as' => 'admin-staff-status',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@delete',
        'as' => 'admin-staff-delete',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@restore',
        'as' => 'admin-staff-restore',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@destroy',
        'as' => 'admin-staff-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onChangePassword',
        'as' => 'admin-staff-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onSavePassword',
        'as' => 'admin-staff-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onPermission',
        'as' => 'admin-staff-permission',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@onSavePermission',
        'as' => 'admin-staff-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffController@export',
        'as' => 'admin-staff-export',
        'namespace' => NULL,
        'prefix' => 'admin/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@index',
        'as' => 'admin-user-list',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onCreate',
        'as' => 'admin-user-create',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onEdit',
        'as' => 'admin-user-edit',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@Save',
        'as' => 'admin-user-save',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/user/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@updateStatus',
        'as' => 'admin-user-status',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@delete',
        'as' => 'admin-user-delete',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@restore',
        'as' => 'admin-user-restore',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@destroy',
        'as' => 'admin-user-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onChangePassword',
        'as' => 'admin-user-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onSavePassword',
        'as' => 'admin-user-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onPermission',
        'as' => 'admin-user-permission',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/user/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@onSavePermission',
        'as' => 'admin-user-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-user-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/user/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@export',
        'as' => 'admin-user-export',
        'namespace' => NULL,
        'prefix' => 'admin/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@index',
        'as' => 'admin-internships-list',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onCreate',
        'as' => 'admin-internships-create',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onEdit',
        'as' => 'admin-internships-edit',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@Save',
        'as' => 'admin-internships-save',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/internships/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@updateStatus',
        'as' => 'admin-internships-status',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@delete',
        'as' => 'admin-internships-delete',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@restore',
        'as' => 'admin-internships-restore',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@destroy',
        'as' => 'admin-internships-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onChangePassword',
        'as' => 'admin-internships-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onSavePassword',
        'as' => 'admin-internships-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onPermission',
        'as' => 'admin-internships-permission',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/internships/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@onSavePermission',
        'as' => 'admin-internships-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-internships-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/internships/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JobController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\JobController@export',
        'as' => 'admin-internships-export',
        'namespace' => NULL,
        'prefix' => 'admin/internships',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@index',
        'as' => 'admin-blog-list',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onCreate',
        'as' => 'admin-blog-create',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onEdit',
        'as' => 'admin-blog-edit',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@Save',
        'as' => 'admin-blog-save',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/blog/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@updateStatus',
        'as' => 'admin-blog-status',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@delete',
        'as' => 'admin-blog-delete',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@restore',
        'as' => 'admin-blog-restore',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@destroy',
        'as' => 'admin-blog-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onChangePassword',
        'as' => 'admin-blog-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onSavePassword',
        'as' => 'admin-blog-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onPermission',
        'as' => 'admin-blog-permission',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/blog/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@onSavePermission',
        'as' => 'admin-blog-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-blog-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/blog/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@export',
        'as' => 'admin-blog-export',
        'namespace' => NULL,
        'prefix' => 'admin/blog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@index',
        'as' => 'admin-placement-type-list',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onCreate',
        'as' => 'admin-placement-type-create',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onEdit',
        'as' => 'admin-placement-type-edit',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@Save',
        'as' => 'admin-placement-type-save',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@updateStatus',
        'as' => 'admin-placement-type-status',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@delete',
        'as' => 'admin-placement-type-delete',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@restore',
        'as' => 'admin-placement-type-restore',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@destroy',
        'as' => 'admin-placement-type-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onChangePassword',
        'as' => 'admin-placement-type-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onSavePassword',
        'as' => 'admin-placement-type-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onPermission',
        'as' => 'admin-placement-type-permission',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/placement-type/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@onSavePermission',
        'as' => 'admin-placement-type-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-placement-type-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/placement-type/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlacementTypeController@export',
        'as' => 'admin-placement-type-export',
        'namespace' => NULL,
        'prefix' => 'admin/placement-type',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@index',
        'as' => 'admin-testimonial-list',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onCreate',
        'as' => 'admin-testimonial-create',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onEdit',
        'as' => 'admin-testimonial-edit',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@Save',
        'as' => 'admin-testimonial-save',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@updateStatus',
        'as' => 'admin-testimonial-status',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@delete',
        'as' => 'admin-testimonial-delete',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@restore',
        'as' => 'admin-testimonial-restore',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@destroy',
        'as' => 'admin-testimonial-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onChangePassword',
        'as' => 'admin-testimonial-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onSavePassword',
        'as' => 'admin-testimonial-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onPermission',
        'as' => 'admin-testimonial-permission',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/testimonial/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@onSavePermission',
        'as' => 'admin-testimonial-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-testimonial-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/testimonial/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TestimonialController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\TestimonialController@export',
        'as' => 'admin-testimonial-export',
        'namespace' => NULL,
        'prefix' => 'admin/testimonial',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'as' => 'admin-customer-list',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onCreate',
        'as' => 'admin-customer-create',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onEdit',
        'as' => 'admin-customer-edit',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@Save',
        'as' => 'admin-customer-save',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/customer/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@updateStatus',
        'as' => 'admin-customer-status',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@delete',
        'as' => 'admin-customer-delete',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@restore',
        'as' => 'admin-customer-restore',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@destroy',
        'as' => 'admin-customer-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onChangePassword',
        'as' => 'admin-customer-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onSavePassword',
        'as' => 'admin-customer-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onPermission',
        'as' => 'admin-customer-permission',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@onSavePermission',
        'as' => 'admin-customer-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@export',
        'as' => 'admin-customer-export',
        'namespace' => NULL,
        'prefix' => 'admin/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@index',
        'as' => 'admin-customer-paid-list',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onCreate',
        'as' => 'admin-customer-paid-create',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onEdit',
        'as' => 'admin-customer-paid-edit',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@Save',
        'as' => 'admin-customer-paid-save',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@updateStatus',
        'as' => 'admin-customer-paid-status',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@delete',
        'as' => 'admin-customer-paid-delete',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@restore',
        'as' => 'admin-customer-paid-restore',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@destroy',
        'as' => 'admin-customer-paid-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onChangePassword',
        'as' => 'admin-customer-paid-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onSavePassword',
        'as' => 'admin-customer-paid-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onPermission',
        'as' => 'admin-customer-paid-permission',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customer-paid/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@onSavePermission',
        'as' => 'admin-customer-paid-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/customer-paid',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-customer-paid-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customer-paid/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerPaidController@export',
        'as' => 'admin-customer-paid-export',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-our-service-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/OurService',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@indexOurService',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@indexOurService',
        'as' => 'admin-our-service-index',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-our-service-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/OurService/Save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@onStoreOurService',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@onStoreOurService',
        'as' => 'admin-our-service-store',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-about-us-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/aboutUs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@indexAboutUs',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@indexAboutUs',
        'as' => 'admin-about-us-index',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-about-us-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/aboutUs/Save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@onStoreAboutUs',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@onStoreAboutUs',
        'as' => 'admin-about-us-store',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@index',
        'as' => 'admin-stock-in-list',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onCreate',
        'as' => 'admin-stock-in-create',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onEdit',
        'as' => 'admin-stock-in-edit',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onView',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onView',
        'as' => 'admin-stock-in-view',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-in/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onSave',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@onSave',
        'as' => 'admin-stock-in-save',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/products/{shop_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@getShopProducts',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@getShopProducts',
        'as' => 'admin-stock-in-products',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/stock-in/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@updateStatus',
        'as' => 'admin-stock-in-status',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-in/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@delete',
        'as' => 'admin-stock-in-delete',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-in/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@restore',
        'as' => 'admin-stock-in-restore',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-in-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-in/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockInController@destroy',
        'as' => 'admin-stock-in-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/stock-in',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-out/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@index',
        'as' => 'admin-stock-out-list',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-out/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onCreate',
        'as' => 'admin-stock-out-create',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-out/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onEdit',
        'as' => 'admin-stock-out-edit',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-out/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onView',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onView',
        'as' => 'admin-stock-out-view',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-out/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onSave',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@onSave',
        'as' => 'admin-stock-out-save',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/stock-out/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@updateStatus',
        'as' => 'admin-stock-out-status',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-out/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@delete',
        'as' => 'admin-stock-out-delete',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-out/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@restore',
        'as' => 'admin-stock-out-restore',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-out-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-out/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOutController@destroy',
        'as' => 'admin-stock-out-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/stock-out',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-transfer/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@index',
        'as' => 'admin-stock-transfer-list',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-transfer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onCreate',
        'as' => 'admin-stock-transfer-create',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-transfer/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onEdit',
        'as' => 'admin-stock-transfer-edit',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-transfer/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onView',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onView',
        'as' => 'admin-stock-transfer-view',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-transfer/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onSave',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onSave',
        'as' => 'admin-stock-transfer-save',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-transfer/update/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@onUpdate',
        'as' => 'admin-stock-transfer-update',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/stock-transfer/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@updateStatus',
        'as' => 'admin-stock-transfer-status',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-transfer/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@delete',
        'as' => 'admin-stock-transfer-delete',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-transfer/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@restore',
        'as' => 'admin-stock-transfer-restore',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-transfer-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stock-transfer/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockTransferController@destroy',
        'as' => 'admin-stock-transfer-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/stock-transfer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-on-hand-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-on-hand/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@index',
        'as' => 'admin-stock-on-hand-list',
        'namespace' => NULL,
        'prefix' => 'admin/stock-on-hand',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-on-hand-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-on-hand/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@onView',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@onView',
        'as' => 'admin-stock-on-hand-view',
        'namespace' => NULL,
        'prefix' => 'admin/stock-on-hand',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-on-hand-onFind' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-on-hand/find/{product_id?}/{shop_id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@onFind',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@onFind',
        'as' => 'admin-stock-on-hand-onFind',
        'namespace' => NULL,
        'prefix' => 'admin/stock-on-hand',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-on-hand-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-on-hand/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockOnHandController@report',
        'as' => 'admin-stock-on-hand-report',
        'namespace' => NULL,
        'prefix' => 'admin/stock-on-hand',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-movement-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-movement/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@index',
        'as' => 'admin-stock-movement-list',
        'namespace' => NULL,
        'prefix' => 'admin/stock-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-movement-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-movement/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@onView',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@onView',
        'as' => 'admin-stock-movement-view',
        'namespace' => NULL,
        'prefix' => 'admin/stock-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-stock-movement-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stock-movement/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Inventory\\StockMovementController@report',
        'as' => 'admin-stock-movement-report',
        'namespace' => NULL,
        'prefix' => 'admin/stock-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@index',
        'as' => 'admin-uom-list',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onCreate',
        'as' => 'admin-uom-create',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onEdit',
        'as' => 'admin-uom-edit',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@Save',
        'as' => 'admin-uom-save',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/uom/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@updateStatus',
        'as' => 'admin-uom-status',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@delete',
        'as' => 'admin-uom-delete',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@restore',
        'as' => 'admin-uom-restore',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@destroy',
        'as' => 'admin-uom-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onChangePassword',
        'as' => 'admin-uom-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onSavePassword',
        'as' => 'admin-uom-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onPermission',
        'as' => 'admin-uom-permission',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uom/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@onSavePermission',
        'as' => 'admin-uom-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-uom-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/uom/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UomController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\UomController@export',
        'as' => 'admin-uom-export',
        'namespace' => NULL,
        'prefix' => 'admin/uom',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-product-by-shop' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@selectProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@selectProduct',
        'as' => 'admin-select-product-by-shop',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-customer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@selectCustomer',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@selectCustomer',
        'as' => 'admin-select-customer',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-supplier' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@selectSupplier',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@selectSupplier',
        'as' => 'admin-select-supplier',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-stock-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/stock-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectProduct',
        'as' => 'admin-select-stock-product',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-stock-shop' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/stock-shop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectShop',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectShop',
        'as' => 'admin-select-stock-shop',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-shopNotIn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/shopNotIn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectShopNotInID',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@stockSelectShopNotInID',
        'as' => 'admin-select-shopNotIn',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-shop-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/shop-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@selectShopProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@selectShopProduct',
        'as' => 'admin-select-shop-product',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-find-shop-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/find-shop-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@findShopProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@findShopProduct',
        'as' => 'admin-select-find-shop-product',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-barber' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/barber',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectBarber',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectBarber',
        'as' => 'admin-select-barber',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-shop' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/shop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectShop',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectShop',
        'as' => 'admin-select-shop',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/type-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectProductSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectProductSearch',
        'as' => 'admin-select-product',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-service' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/type-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectServiceSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectServiceSearch',
        'as' => 'admin-select-service',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-shop-in-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/shop-in-product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@productInShop',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@productInShop',
        'as' => 'admin-select-shop-in-product',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-position' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/position',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectPositionSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectPositionSearch',
        'as' => 'admin-select-position',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-sector' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/sector',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectSectorSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectSectorSearch',
        'as' => 'admin-select-sector',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-category' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectCategorySearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectCategorySearch',
        'as' => 'admin-select-category',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-uom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/uom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectUOMSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectUOMSearch',
        'as' => 'admin-select-uom',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-select-placement-type' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/select/placement-type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectPlacementTypeSearch',
        'controller' => 'App\\Http\\Controllers\\Admin\\SelectController@SelectPlacementTypeSearch',
        'as' => 'admin-select-placement-type',
        'namespace' => NULL,
        'prefix' => 'admin/select',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@index',
        'as' => 'admin-order-list',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@onCreate',
        'as' => 'admin-order-create',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/order/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@updateStatus',
        'as' => 'admin-order-status',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-list-product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/list-product/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@product',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@product',
        'as' => 'admin-order-list-product',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@onEdit',
        'as' => 'admin-order-edit',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@show',
        'as' => 'admin-order-detail',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@Save',
        'as' => 'admin-order-save',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@delete',
        'as' => 'admin-order-delete',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/restore/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@restore',
        'as' => 'admin-order-restore',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@destroy',
        'as' => 'admin-order-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@report',
        'as' => 'admin-order-report',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-payment-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/order/payment-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@getPaymentDetails',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@getPaymentDetails',
        'as' => 'admin-order-payment-details',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-add-payment' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/add-payment/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@addPayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@addPayment',
        'as' => 'admin-order-add-payment',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-update-payment' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/order/update-payment/{paymentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@updatePayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@updatePayment',
        'as' => 'admin-order-update-payment',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-delete-payment' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/order/delete-payment/{paymentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@deletePayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@deletePayment',
        'as' => 'admin-order-delete-payment',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-send-payment-reminder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/send-payment-reminder/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@sendPaymentReminder',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@sendPaymentReminder',
        'as' => 'admin-order-send-payment-reminder',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/cancel/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@cancelOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@cancelOrder',
        'as' => 'admin-order-cancel',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-order-update-payment-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/order/update-payment-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@updatePaymentStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@updatePaymentStatus',
        'as' => 'admin-order-update-payment-status',
        'namespace' => NULL,
        'prefix' => 'admin/order',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/remaining-amount/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@index',
        'as' => 'admin-remaining-amount-list',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/remaining-amount/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@index',
        'as' => 'admin-remaining-amount-create',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/remaining-amount/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@show',
        'as' => 'admin-remaining-amount-detail',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-payment-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/remaining-amount/payment-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@getPaymentDetails',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@getPaymentDetails',
        'as' => 'admin-remaining-amount-payment-details',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-add-payment' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/remaining-amount/add-payment/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@addPayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@addPayment',
        'as' => 'admin-remaining-amount-add-payment',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-update-payment' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/remaining-amount/update-payment/{paymentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@updatePayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@updatePayment',
        'as' => 'admin-remaining-amount-update-payment',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-delete-payment' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/remaining-amount/delete-payment/{paymentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@deletePayment',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@deletePayment',
        'as' => 'admin-remaining-amount-delete-payment',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-send-reminder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/remaining-amount/send-reminder/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@sendPaymentReminder',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@sendPaymentReminder',
        'as' => 'admin-remaining-amount-send-reminder',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-remaining-amount-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/remaining-amount/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\RemainingAmountController@report',
        'as' => 'admin-remaining-amount-report',
        'namespace' => NULL,
        'prefix' => 'admin/remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-setting-setting' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/setting/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'as' => 'admin-setting-setting',
        'namespace' => NULL,
        'prefix' => 'admin/setting',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-setting-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/setting/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@store',
        'as' => 'admin-setting-save',
        'namespace' => NULL,
        'prefix' => 'admin/setting',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-setting-invoice-preview' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/setting/invoice/preview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@preview',
        'controller' => 'App\\Http\\Controllers\\Admin\\InvoiceSettingController@preview',
        'as' => 'admin-setting-invoice-preview',
        'namespace' => NULL,
        'prefix' => 'admin/setting',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/file-manager/index',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@index',
        'controller' => 'App\\Services\\FileManager@index',
        'as' => 'admin-file-manager-index',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-first' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/file-manager/first',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@first',
        'controller' => 'App\\Services\\FileManager@first',
        'as' => 'admin-file-manager-first',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-files' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/file-manager/files',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@getFiles',
        'controller' => 'App\\Services\\FileManager@getFiles',
        'as' => 'admin-file-manager-files',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-folders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/file-manager/folders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@getFolders',
        'controller' => 'App\\Services\\FileManager@getFolders',
        'as' => 'admin-file-manager-folders',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/file-manager/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@uploadFile',
        'controller' => 'App\\Services\\FileManager@uploadFile',
        'as' => 'admin-file-manager-upload',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-rename-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/file-manager/rename-file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@renameFile',
        'controller' => 'App\\Services\\FileManager@renameFile',
        'as' => 'admin-file-manager-rename-file',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-delete-file' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/file-manager/delete-file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@deleteFile',
        'controller' => 'App\\Services\\FileManager@deleteFile',
        'as' => 'admin-file-manager-delete-file',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-create-folder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/file-manager/create-folder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@createFolder',
        'controller' => 'App\\Services\\FileManager@createFolder',
        'as' => 'admin-file-manager-create-folder',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-rename-folder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/file-manager/rename-folder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@renameFolder',
        'controller' => 'App\\Services\\FileManager@renameFolder',
        'as' => 'admin-file-manager-rename-folder',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-delete-folder' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/file-manager/delete-folder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@deleteFolder',
        'controller' => 'App\\Services\\FileManager@deleteFolder',
        'as' => 'admin-file-manager-delete-folder',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-delete-all' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/file-manager/delete-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@deleteAll',
        'controller' => 'App\\Services\\FileManager@deleteAll',
        'as' => 'admin-file-manager-delete-all',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-file-manager-restore-all' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/file-manager/restore-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Services\\FileManager@restoreAll',
        'controller' => 'App\\Services\\FileManager@restoreAll',
        'as' => 'admin-file-manager-restore-all',
        'namespace' => NULL,
        'prefix' => 'admin/file-manager',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-page-page' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/page/{type?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PageController@page',
        'controller' => 'App\\Http\\Controllers\\Admin\\PageController@page',
        'as' => 'admin-page-page',
        'namespace' => NULL,
        'prefix' => 'admin/page',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-page-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/page/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PageController@onSave',
        'controller' => 'App\\Http\\Controllers\\Admin\\PageController@onSave',
        'as' => 'admin-page-save',
        'namespace' => NULL,
        'prefix' => 'admin/page',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-contact-contact' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contact/{type?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ContactController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ContactController@index',
        'as' => 'admin-contact-contact',
        'namespace' => NULL,
        'prefix' => 'admin/contact',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-contact-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/contact/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ContactController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ContactController@store',
        'as' => 'admin-contact-save',
        'namespace' => NULL,
        'prefix' => 'admin/contact',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/list/{status?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@index',
        'as' => 'admin-staff-expense-list',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onCreate',
        'as' => 'admin-staff-expense-create',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onEdit',
        'as' => 'admin-staff-expense-edit',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/save/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@Save',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@Save',
        'as' => 'admin-staff-expense-save',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/status/{id}/{status}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@updateStatus',
        'as' => 'admin-staff-expense-status',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/delete/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@delete',
        'as' => 'admin-staff-expense-delete',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/restore/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@restore',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@restore',
        'as' => 'admin-staff-expense-restore',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/destroy/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@destroy',
        'as' => 'admin-staff-expense-destroy',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-change-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/change-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onChangePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onChangePassword',
        'as' => 'admin-staff-expense-change-password',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-save-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/save-password/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onSavePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onSavePassword',
        'as' => 'admin-staff-expense-save-password',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-permission' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onPermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onPermission',
        'as' => 'admin-staff-expense-permission',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-save-permission' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/staff-expense/save-permission/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onSavePermission',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@onSavePermission',
        'as' => 'admin-staff-expense-save-permission',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@export',
        'as' => 'admin-staff-expense-export',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-staff-expense-staff-history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/staff-expense/staff/{staffId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@staffHistory',
        'controller' => 'App\\Http\\Controllers\\Admin\\StaffExpenseController@staffHistory',
        'as' => 'admin-staff-expense-staff-history',
        'namespace' => NULL,
        'prefix' => 'admin/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-sales-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@index',
        'as' => 'admin-report-sales-index',
        'namespace' => NULL,
        'prefix' => 'admin/report/sales',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-sales-daily' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/sales/daily',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@daily',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@daily',
        'as' => 'admin-report-sales-daily',
        'namespace' => NULL,
        'prefix' => 'admin/report/sales',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-sales-monthly' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/sales/monthly',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@monthly',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@monthly',
        'as' => 'admin-report-sales-monthly',
        'namespace' => NULL,
        'prefix' => 'admin/report/sales',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-sales-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/sales/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@report',
        'as' => 'admin-report-sales-report',
        'namespace' => NULL,
        'prefix' => 'admin/report/sales',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-sales-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/sales/details/{period}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@details',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\SalesReportController@details',
        'as' => 'admin-report-sales-details',
        'namespace' => NULL,
        'prefix' => 'admin/report/sales',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-order-transaction-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/order-transaction',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@index',
        'as' => 'admin-report-order-transaction-index',
        'namespace' => NULL,
        'prefix' => 'admin/report/order-transaction',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-order-transaction-daily' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/order-transaction/daily',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@daily',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@daily',
        'as' => 'admin-report-order-transaction-daily',
        'namespace' => NULL,
        'prefix' => 'admin/report/order-transaction',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-order-transaction-monthly' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/order-transaction/monthly',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@monthly',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@monthly',
        'as' => 'admin-report-order-transaction-monthly',
        'namespace' => NULL,
        'prefix' => 'admin/report/order-transaction',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-order-transaction-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/order-transaction/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@report',
        'as' => 'admin-report-order-transaction-report',
        'namespace' => NULL,
        'prefix' => 'admin/report/order-transaction',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-order-transaction-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/order-transaction/details/{period}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@details',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\OrderTransactionReportController@details',
        'as' => 'admin-report-order-transaction-details',
        'namespace' => NULL,
        'prefix' => 'admin/report/order-transaction',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-inventory-movement-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/inventory-movement',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@index',
        'as' => 'admin-report-inventory-movement-index',
        'namespace' => NULL,
        'prefix' => 'admin/report/inventory-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-inventory-movement-daily' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/inventory-movement/daily',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@daily',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@daily',
        'as' => 'admin-report-inventory-movement-daily',
        'namespace' => NULL,
        'prefix' => 'admin/report/inventory-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-inventory-movement-monthly' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/inventory-movement/monthly',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@monthly',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@monthly',
        'as' => 'admin-report-inventory-movement-monthly',
        'namespace' => NULL,
        'prefix' => 'admin/report/inventory-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-inventory-movement-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/inventory-movement/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@report',
        'as' => 'admin-report-inventory-movement-report',
        'namespace' => NULL,
        'prefix' => 'admin/report/inventory-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-inventory-movement-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/inventory-movement/details/{period}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@details',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\InventoryMovementReportController@details',
        'as' => 'admin-report-inventory-movement-details',
        'namespace' => NULL,
        'prefix' => 'admin/report/inventory-movement',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-customer-remaining-amount-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/customer-remaining-amount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\CustomerRemainingAmountReportController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\CustomerRemainingAmountReportController@index',
        'as' => 'admin-report-customer-remaining-amount-index',
        'namespace' => NULL,
        'prefix' => 'admin/report/customer-remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-customer-remaining-amount-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/customer-remaining-amount/details/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\CustomerRemainingAmountReportController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\CustomerRemainingAmountReportController@show',
        'as' => 'admin-report-customer-remaining-amount-details',
        'namespace' => NULL,
        'prefix' => 'admin/report/customer-remaining-amount',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'customer' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-staff-expense-index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/staff-expense',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@index',
        'as' => 'admin-report-staff-expense-index',
        'namespace' => NULL,
        'prefix' => 'admin/report/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-staff-expense-daily' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/staff-expense/daily',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@daily',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@daily',
        'as' => 'admin-report-staff-expense-daily',
        'namespace' => NULL,
        'prefix' => 'admin/report/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-staff-expense-monthly' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/staff-expense/monthly',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@monthly',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@monthly',
        'as' => 'admin-report-staff-expense-monthly',
        'namespace' => NULL,
        'prefix' => 'admin/report/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-staff-expense-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/staff-expense/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@report',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@report',
        'as' => 'admin-report-staff-expense-report',
        'namespace' => NULL,
        'prefix' => 'admin/report/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-report-staff-expense-details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/staff-expense/details/{period}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
          1 => 'AdminGuard',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@details',
        'controller' => 'App\\Http\\Controllers\\Admin\\Report\\StaffExpenseReportController@details',
        'as' => 'admin-report-staff-expense-details',
        'namespace' => NULL,
        'prefix' => 'admin/report/staff-expense',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-clear-cache-s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/clear-cache-s',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:171:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'cache:clear\');
    \\Illuminate\\Support\\Facades\\Artisan::call(\'config:clear\');
    return "Cache is cleared";
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006b80000000000000000";}";s:4:"hash";s:44:"G7wSvTPLHCEpkFPH84ScfwnmxjaTvnt3EFJUl9rnotM=";}}',
        'as' => 'admin-clear-cache-s',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-clear-cache' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/clear-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'admin',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:330:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:111:"function () {
    \\Illuminate\\Support\\Facades\\Artisan::call(\'optimize:clear\');
    return "Cache is cleared";
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007ba0000000000000000";}";s:4:"hash";s:44:"3i/G0/qmYE3HozBWauWHFDOe40pWSu3dz4+BEYi4j/U=";}}',
        'as' => 'admin-clear-cache',
        'namespace' => NULL,
        'prefix' => 'admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
